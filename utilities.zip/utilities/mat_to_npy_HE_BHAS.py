# -*- coding: utf-8 -*-
"""
Created on Wed May 31 09:03:20 2023

@author: zaidi
"""

import os
from tqdm import tqdm
from glob import glob
import numpy as np
from mat4py import loadmat

src_data_path = '../data/BHAS/DE/mat' 
dst_data_path = '../data/BHAS/DE/npy'
dst_data_path_cropped = '../data/BHAS/DE/npy_cropped'

files = glob(os.path.join(src_data_path,'*.mat'))

def crop_image(img, test=False):
    '''
    Works on numpy images
    '''
    y,x = img.shape

    # cropx=int(x*0.60) # for training anf VFA x
    
    # if test:
    #     cropx=int(x*0.60)
        

    # startx = int(x*0.10)
    # startx = int(x*0.10)
    starty = int(y*0.50)  # for training and VFA int(y*0.50)
    return img[starty:y,:]

for file in tqdm(files):
    try:
        aa = loadmat(file)
        
        image_2d1 = np.array(aa[list(aa.keys())[-1]])
        file_name = file.split('\\')[-1].split('.mat')[0]
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape
    
        # image_2d1=np.fliplr(image_2d1)
        
        image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        img=crop_image(image_2d1, None)
        # np.save(os.path.join(dst_data_path,file_name+'.npy'),image_2d1)
        np.save(os.path.join(dst_data_path_cropped,file_name+'.npy'),img)
    except:
        print('error')
        print('fname:'+file_name)
        pass
    
