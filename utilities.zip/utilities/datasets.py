# -*- coding: utf-8 -*-
"""
Created on Tue May  2 09:23:05 2023

@author: zaidi
"""

import torch
import pandas as pd
from tqdm import tqdm
import os
import numpy as np
from PIL import Image, ImageOps
import  matplotlib.pyplot as plt
from glob import glob
from torch.utils.data import Dataset, DataLoader
import pydicom as dicom
from tqdm import tqdm
from mat4py import loadmat
import pandas as pd
import cv2


SIZE = 320




def Rescale(sample,output_size):
        #rescaled = resize(sample[0], output_size, mode='constant')
        rescaled=sample[0]
        rescaled= np.repeat(rescaled[:,:, np.newaxis], 3, -1)
        return (rescaled, sample[1])

def ToTensor_(sample):
        image, label = sample
        # swap color axis because
        # numpy image: H x W x C
        # torch image: C X H X W
        image = image.transpose((2, 0, 1))
        return (torch.FloatTensor(image), label)

def crop_image(img, test=False):
    '''
    Works on numpy images
    '''
    y,x = img.shape

    # cropx=int(x*0.60) # for training anf VFA x
    
    # if test:
    #     cropx=int(x*0.60)
        

    startx = int(x*0.10)
    # startx = int(x*0.10)
    starty = int(y*0.50)  # for training and VFA int(y*0.50)
    return img[starty:y,:]


class manitoba_1916(Dataset):
    def __init__(self, data_path=None, file_path=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.mat'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.mat'
        label = self.df['labels'][index]
        file_path = os.path.join(self.dir_base,fname)
        
        image_2d1 = np.array(loadmat(file_path)['BMD'])

        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.mat')[0])


class manitoba_1916_npy_cropped(Dataset):
    def __init__(self, data_path=None, file_path=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.npy')[0])


class manitoba_1916_npy_cropped_reg_and_gran(Dataset):#step2
    def __init__(self, data_path=None, file_path=None, file_path_granular=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        self.file_path_granular = file_path_granular
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        self.df_fine_labels = np.load(self.file_path_granular, allow_pickle=True)
        
        # self.transforms = transforms
        self.d= self.df_fine_labels.flatten()

        self.d=self.d[0]
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        
        label = label.astype(np.float32)
        fine_label = np.array(self.d[fname.split('.npy')[0]])
        
        fine_label = torch.from_numpy(fine_label.astype(np.float32))
        fine_label = fine_label[1:-1] # L1_A, L1_P,L2_A, L2_P,L3_A, L3_P,L4_A, L4_P
        
        fine_label=torch.Tensor(fine_label).long()
        # label = torch.from_numpy(label.astype(np.float32))
        
        fine_label_4 = fine_label.reshape(-1,2).sum(1)
        
        fine_label_4 = fine_label_4/6.0
        
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.npy')[0], fine_label)

class manitoba_1916_npy_cropped_reg_and_gran_predict(Dataset):#####
    def __init__(self, data_path=None, transforms=None):
        # self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        # self.df = pd.read_csv(self.file_path)

        # self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        # self.df_fine_labels = np.load('ids_to_score-bill-fine.npy', allow_pickle=True)
        
        # self.transforms = transforms
        # self.d= self.df_fine_labels.flatten()

        # self.d=self.d[0]
        
    def __len__(self):
        return len(self.mat_files)
    
    def __getitem__(self, index):
        
        

        
        fname = self.mat_files[index].split('\\')[-1]
        # label = self.df['labels'][index]
        
        # label = label.astype(np.float32)
        # fine_label = np.array(self.d[fname.split('.npy')[0]])
        
        # fine_label = torch.from_numpy(fine_label.astype(np.float32))
        # fine_label = fine_label[1:-1] # L1_A, L1_P,L2_A, L2_P,L3_A, L3_P,L4_A, L4_P
        
        # fine_label=torch.Tensor(fine_label).long()
        # label = torch.from_numpy(label.astype(np.float32))
        
        # fine_label_4 = fine_label.reshape(-1,2).sum(1)
        
        # fine_label_4 = fine_label_4/6.0
        
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, fname.split('.npy')[0])

class manitoba_1916_npy_cropped_reg_and_gran_test(Dataset):
    def __init__(self, data_path=None, transforms=None):
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        

        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        
    def __len__(self):
        return len(self.mat_files)
    
    def __getitem__(self, index):
        

        img = np.load(self.mat_files[index])
        fname = self.mat_files[index].split('\\')[-1].split('.npy')[0]
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (fname, img)

class manitoba_1916_npy_full_sized(Dataset):
    def __init__(self, data_path=None, file_path=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(300, 600), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.mat')[0])


class us_326_npy_cropped_reg_and_gran(Dataset):
    def __init__(self, data_path=None, file_path=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        self.df_fine_labels = np.load('ids_to_score-us-fine.npy', allow_pickle=True)
        
        # self.transforms = transforms
        self.d= self.df_fine_labels.flatten()

        self.d=self.d[0]
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        
        label = label.astype(np.float32)
        fine_label = np.array(self.d[fname.split('.npy')[0]])
        
        fine_label = torch.from_numpy(fine_label.astype(np.float32))
        fine_label = fine_label[1:-1] # L1_A, L1_P,L2_A, L2_P,L3_A, L3_P,L4_A, L4_P
        
        fine_label=torch.Tensor(fine_label).long()
        # label = torch.from_numpy(label.astype(np.float32))
        
        fine_label_4 = fine_label.reshape(-1,2).sum(1)
        
        fine_label_4 = fine_label_4/6.0
        
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.npy')[0], fine_label)

class model_182_npy_cropped_reg_and_gran(Dataset):
    def __init__(self, data_path=None, file_path=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        self.df_fine_labels = np.load('ids_to_score-model-fine.npy', allow_pickle=True)
        
        # self.transforms = transforms
        self.d= self.df_fine_labels.flatten()

        self.d=self.d[0]
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        
        label = label.astype(np.float32)
        fine_label = np.array(self.d[fname.split('.npy')[0]])
        
        fine_label = torch.from_numpy(fine_label.astype(np.float32))
        fine_label = fine_label[1:-1] # L1_A, L1_P,L2_A, L2_P,L3_A, L3_P,L4_A, L4_P
        
        fine_label=torch.Tensor(fine_label).long()
        # label = torch.from_numpy(label.astype(np.float32))
        
        fine_label_4 = fine_label.reshape(-1,2).sum(1)
        
        fine_label_4 = fine_label_4/6.0
        
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.npy')[0], fine_label)

class us_326_model_182_combined_npy_cropped_reg_and_gran(Dataset):
    def __init__(self, data_path=None, file_path=None,  file_path_granular=None, transforms=None):
        self.file_path = file_path
        self.data_path = data_path
        self.mat_files = glob(os.path.join(self.data_path,'*.npy'))
        self.file_path_granular = file_path_granular
        # self.a=[]
        # for i in self.mat_files:
        #     self.a.append(i.split('\\')[-1].split('.mat')[0])
        
        self.df = pd.read_csv(self.file_path)

        self.data_path = data_path
        self.transforms = transforms
        self.dir_base = os.path.dirname(self.mat_files[0])
        
        self.df_fine_labels = np.load(self.file_path_granular, allow_pickle=True)
        
        # self.transforms = transforms
        self.d= self.df_fine_labels.flatten()

        self.d=self.d[0]
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, index):
        

        
        fname = self.df['image_id'][index] +'.npy'
        label = self.df['labels'][index]
        
        label = label.astype(np.float32)
        fine_label = np.array(self.d[fname.split('.npy')[0]])
        
        fine_label = torch.from_numpy(fine_label.astype(np.float32))
        fine_label = fine_label[1:-1] # L1_A, L1_P,L2_A, L2_P,L3_A, L3_P,L4_A, L4_P
        
        fine_label=torch.Tensor(fine_label).long()
        # label = torch.from_numpy(label.astype(np.float32))
        
        fine_label_4 = fine_label.reshape(-1,2).sum(1)
        
        fine_label_4 = fine_label_4/6.0
        
        file_path = os.path.join(self.dir_base,fname)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        img = np.load(file_path)
        
        # image_2d1 = np.array(loadmat(file_path)['BMD'])
        # shape = image_2d1.shape

        # image_2d1=np.fliplr(image_2d1)
        
        # image_2d1 = (image_2d1-(-32767))/(32767-(-32767))
        # image_2d1 = image_2d1/2048
        
        # img=crop_image(image_2d1, None)
        
        # img = np.uint8(img*255)
        # img_crop = np.dstack([img]*3)
        img = np.dstack([img]*3)
        # image_2d = (np.maximum(image_2d,0) / image_2d1.max())
        # img_crop=cv2.resize(img_crop, dsize=(300, 300), interpolation=cv2.INTER_AREA)
        img=cv2.resize(img, dsize=(SIZE, SIZE), interpolation=cv2.INTER_AREA)
        # sample = (image_2d, 0)
        # sample=Rescale(sample,(300,300))
        # sample= ToTensor_(sample)
        
        # img, label=sample
        if self.transforms is not None:
            img = self.transforms(np.uint8(img*255))
        
        # img_crop = img_global[:,300:,:]
        
        # file_name = file_path.split('\\')[-1].split('.dcm')[0]
                        
        return (img, np.float32(label/24.0), fname.split('.npy')[0], fine_label)
    
