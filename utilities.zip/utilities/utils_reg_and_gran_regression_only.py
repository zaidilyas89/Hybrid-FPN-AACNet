# -*- coding: utf-8 -*-
"""
Created on Wed May 17 14:29:59 2023

@author: zaidi
"""
import torch
import torchvision.transforms as transforms
import time
import copy
from .pytorchtools import EarlyStopping
from tqdm import tqdm
from sklearn.metrics import confusion_matrix
from sklearn.metrics import cohen_kappa_score
import scipy
import numpy as np
from PIL import Image
import pandas as pd
import logging
def define_transforms(opt):
    train_CL_transforms = transforms.Compose([transforms.ToPILImage(),
                                     transforms.RandomApply(torch.nn.ModuleList([transforms.RandomRotation(15,fill=0),
                                                            transforms.RandomAffine(degrees=0, shear=(0.05),fill=0,),
                                                            transforms.RandomAffine(degrees=0, translate=(0.05, 0.05),fill=0)]), p=0.5),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])

    val_transforms = transforms.Compose([transforms.ToPILImage(),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])
    
    train_transforms = transforms.Compose([
                                    transforms.ToPILImage(),
                            
                                    transforms.RandomApply(torch.nn.ModuleList([
                                        transforms.RandomAffine(degrees=10, translate=(
                                            0.05, 0.05), scale=(.95, 1.05), shear=(0.01, 0.03)),
                                        transforms.RandomAffine(
                                            degrees=5),
                                        transforms.RandomAffine(
                                            degrees=0, translate=(0.1, 0.1)),
                                        transforms.RandomAffine(
                                            degrees=0, scale=(.95, 1.05)),
                                        transforms.RandomAffine(
                                            degrees=0, shear=(0.005, 0.02)),
                                    ]), p=0.5),
                            
                                    transforms.Resize(
                                        opt['shape'][0], interpolation=Image.NEAREST),
                            
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])
                            

    # train_transforms = transforms.Compose([
    #                                 transforms.ToPILImage(),
                            
    #                                 transforms.RandomApply(torch.nn.ModuleList([
    #                                     transforms.RandomAffine(degrees=10, translate=(
    #                                         0.1, 0.1), scale=(.9, 1.1), shear=(0.01, 0.03)),
    #                                     transforms.RandomAffine(
    #                                         degrees=5),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, translate=(0.1, 0.1)),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, scale=(.9, 1.1)),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, shear=(0.005, 0.02)),
    #                                 ]), p=0.5),
                            
    #                                 transforms.Resize(
    #                                     opt['shape'][0], interpolation=Image.NEAREST),
                            
    #                                 transforms.ToTensor(),
    #                                 transforms.Normalize(
    #                                    opt['mean'], opt['std'])
                            
    #                             ])
    
    return train_transforms, val_transforms

def r2_score(target, prediction):
    """Calculates the r2 score of the model
    
    Args-
        target- Actual values of the target variable
        prediction- Predicted values, calculated using the model
        
    Returns- 
        r2- r-squared score of the model
    """
    r2 = 1- torch.sum((target-prediction)**2) / torch.sum((target-target.float().mean())**2)
    return r2

def train_model(model, criterion_aac_score, criterion_L1A, criterion_L1P, criterion_L2A, criterion_L2P, criterion_L3A, criterion_L3P, criterion_L4A, criterion_L4P, optimizer, scheduler, train_loader, val_loader, device, loss_option, logger, fold, num_epochs=25, patience = 50):
    dataloaders = {}
    dataloaders['train'] = train_loader
    dataloaders['val'] = val_loader
    since = time.time()
    patience=patience
    
    
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    history = {'train_loss':[], 'train_acc':[], 'val_loss':[], 'val_acc':[], 'test_loss':[], 'test_acc':[]}
    bfn=0.0
    best_precision=0.0
    best_recall=0.0
    best_auc =0.0
    best_specificity=0.0
    flag=0
    flag2=0
    flag3=0
    corr_loss=0.0
    btp=0
    bfp=0 
    btn=0
    bfn=0
    bsen=0.0 
    bspec=0.0
    bauc=0.0
    bcorr=0.0
    bp=0.0
    brho=0.0
    bsp=0.0
    bacc_all=0.0
    train_losses = []
    # to track the validation loss as the model trains
    valid_losses = []
    # to track the average training loss per epoch as the model trains
    avg_train_losses = []
    # to track the average validation loss per epoch as the model trains
    avg_valid_losses = [] 
    
    # details = {'train_id':[], 'val_id':[],'test_id':[],'train_pred':[], 'val_pred':[], 'test_pred':[], 'train_gt':[], 'val_gt':[], 'test_gt':[]}
    details = {'train_id':[], 'val_id':[],'test_id':[],'train_pred':[], 'val_pred':[], 'test_pred':[], 'train_gt':[],'val_gt':[], 'test_gt':[], 'train_gt_gran':[], 'val_gt_gran':[], 'test_gt_gran':[] , 'train_pred_gran':[], 'val_pred_gran':[], 'test_pred_gran':[]}

    # initialize the early_stopping object
    early_stopping = EarlyStopping(patience=patience, verbose=True)
    flag=0
    for epoch in tqdm(range(num_epochs)):
        # print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        # print('-' * 10)
        if epoch%2==0:
            option=['train','val']#,'train2','val']
        else:
            option=['train','val']
        # Each epoch has a training and validation phase
        
        for phase in option:
            if phase == 'train':
                phase='train'

                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            running_loss = 0.0
            runningr2 = 0.0
                                    
            running_ppv=0.0
            running_npv=0.0
            running_kappa=0.0
            running_corrects = 0
            runningtp=[0,0,0]
            runningfp=[0,0,0]
            runningtn=[0,0,0]
            runningfn=[0,0,0]
            running_acc=[0.0,0.0, 0.0]

            # Iterate over data.
            count=0
            
    
            l_c=[]
            o_c=[]

            for batch_,(inputs, labels, name, captions_target) in enumerate(dataloaders[phase]):

                inputs = inputs.to(device)
                labels = labels.to(device)
                captions_target = captions_target.to(device)

                labels_class = labels.cpu().detach().numpy().copy()

                labels1 = (labels_class*24) >= 6
                labels2 = (labels_class*24) < 2

                labels1 = labels1*2
                labels2 = labels2*1
                labels3 = labels_class*0

                labels_class = labels1+labels2+labels3

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    outputs_ = model(inputs)
                    # outputs = outputs[:, 0]
                    # if isinstance(outputs, tuple):
                    #     outputs = outputs[0][:][0]
                    #_, preds = torch.max(outputs, 1)

                    # weight=weighted_mse_loss(wts,labels)
                    # weight=weight.to(device)
                    # loss=torch.sum(weight * (outputs - labels) ** 2)

                    outputs_max_values =outputs_[1].max(dim=-1).indices.cpu().detach().numpy().copy()
                    
                    
                    loss_L1A =  criterion_L1A(outputs_[1][:,0,:],captions_target[:,0])
                    loss_L1P =  criterion_L1P(outputs_[1][:,1,:],captions_target[:,1])
                    
                    loss_L2A =  criterion_L2A(outputs_[1][:,2,:],captions_target[:,2])
                    loss_L2P =  criterion_L2P(outputs_[1][:,3,:],captions_target[:,3])
                    
                    loss_L3A =  criterion_L3A(outputs_[1][:,4,:],captions_target[:,4])
                    loss_L3P =  criterion_L3P(outputs_[1][:,5,:],captions_target[:,5])
                    
                    loss_L4A =  criterion_L4A(outputs_[1][:,6,:],captions_target[:,6])
                    loss_L4P =  criterion_L4P(outputs_[1][:,7,:],captions_target[:,7])        
                    
                    output_gran = outputs_[1].softmax(2).argmax(2).detach().cpu()
                    # outputs = (outputs[1].softmax(2).argmax(2).sum(1)/24).unsqueeze(1)
                    captions_1 = (captions_target.sum(1)/24).unsqueeze(1)
                    loss_aac = criterion_aac_score(outputs_[0],captions_1)    
                    
                    loss_aac_gran = loss_L1A + loss_L1P + loss_L2A + loss_L2P + loss_L3A + loss_L3P + loss_L4A + loss_L4P
                    
                    loss = (loss_aac + loss_aac_gran)/2
                    # outputs_1 = outputs[1].squeeze(1)
                    output_gran_ = (output_gran/24).cuda()
                    outputs_aac = outputs_[0][:, 0].cuda()
                    outputs = (output_gran_.sum(1) + outputs_aac)/2
                        
                    # loss = criterion(outputs*24, labels*24)
                        
                        
                    r2=r2_score(outputs, labels)
                    
                    
                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()
                        
                        
                        
                preds=outputs.cpu().detach().numpy().copy()
                
                
                preds1= (preds*24)>= 6
                preds2= (preds*24)<2

                preds1=preds1*2
                preds2=preds2*1
                preds3=preds*0
                
                
                preds = preds1+preds2+preds3
                

                
                cnf_matrix = confusion_matrix(preds, torch.from_numpy(labels_class),labels=[0,1, 2])
                kappa= cohen_kappa_score(preds, torch.from_numpy(labels_class),labels=[0,1, 2])
                np.set_printoptions(precision=2)
                # plt.figure()
                # plot_confusion_matrix(cnf_matrix, classes=['med', 'low', 'high'],
                #                       title='Confusion matrix, without normalization')
                
                #############################################################################
                # https://towardsdatascience.com/multi-class-classification-extracting-performance-metrics-from-the-confusion-matrix-b379b427a872
                FP = cnf_matrix.sum(axis=0) - np.diag(cnf_matrix) 
                FN = cnf_matrix.sum(axis=1) - np.diag(cnf_matrix)
                TP = np.diag(cnf_matrix)
                TN = cnf_matrix.sum() - (FP + FN + TP)
                FP = FP.astype(float)
                FN = FN.astype(float)
                TP = TP.astype(float)
                TN = TN.astype(float)
                
                # Sensitivity, hit rate, recall, or true positive rate
                TPR = TP/(TP+ 0.000000000000000001+FN + 0.000000000000000001)
                # Specificity or true negative rate
                TNR = TN/(TN+ 0.000000000000000001+FP + 0.000000000000000001) 
                
                
                # Precision or positive predictive value
                PPV = TP/(TP+ 0.000000000000000001+FP+ 0.000000000000000001)
                # Negative predictive value
                NPV = TN/(TN+ 0.000000000000000001+FN+ 0.000000000000000001)
                running_kappa+=kappa
                # # Fall out or false positive rate
                # FPR = FP/(FP+TN)
                # # False negative rate
                # FNR = FN/(TP+FN)
                # # False discovery rate
                # FDR = FP/(TP+FP)
                # # Overall accuracy for each class
                ACC = (TP+TN)/(TP+FP+FN+TN)
                #######################################################################################################

                l_c+=list(labels.cpu().detach().numpy())
                o_c+=list(outputs.cpu().detach().numpy())
                #auc=0.1
                
                
                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(torch.from_numpy(preds) == torch.from_numpy(labels_class))
                runningtp+=TP
                runningfp+=FP
                runningtn+=TN
                runningfn+=FN
                running_acc+=ACC
                runningr2+=r2
                
                running_ppv+=PPV
                running_npv+=NPV
                
                
                count+=len(labels_class)
                details["%s_id"%(phase)].append(name)
                details["%s_pred"%(phase)].extend(outputs.cpu().detach().numpy())
                details["%s_gt"%(phase)].extend(labels.cpu().detach().numpy())
                details["%s_gt_gran"%(phase)].extend(captions_target.cpu().detach().numpy())
                details["%s_pred_gran"%(phase)].extend(output_gran.cpu().detach().numpy())        
            # if phase=='train':          
            #     if scheduler:
            #         scheduler.step()
                
                
            epoch_loss = running_loss / count
            epoch_r2 = runningr2 / count
            epoch_acc = (running_corrects.double() / count) *100
            epoch_acc_all=(running_acc / (batch_+1)) *100
            
            
            epoch_ppv=(running_ppv / (batch_+1)) *100
            epoch_npv=(running_npv / (batch_+1)) *100
            epoch_kappa=(running_kappa / (batch_+1)) *100
 
            epochtp=runningtp
            epochfp=runningfp
            epochtn=runningtn
            epochfn=runningfn




            epochauc=0.1#roc_auc_score(l_c, o_c)
            #precision=(epochtp/(epochtp+epochfp+0.00001)) *100
            recall=(epochtp/(epochtp+epochfn+0.00001)) *100
            specificity=(epochtn/(epochtn+epochfp+0.00001)) *100
            #corr, _ = pearsonr(l_c, o_c)
            corr, p = scipy.stats.pearsonr(l_c, o_c)
            if phase=='train':
                corr_loss=corr
            rho, sp = scipy.stats.spearmanr(l_c, o_c)
            print('____________________________________________________________________________________')
            print('fold_'+str(fold))
            print('{} Loss: {:.3f} R2: {:.3f} Acc: {:.3f} , pearson {:3f}'.format(phase, epoch_loss, epoch_r2,  epoch_acc, corr))
            print('*** Class Accuracy***')
            print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(epoch_acc_all[1], epoch_acc_all[0], epoch_acc_all[2] ))
            print('Mean Accuracy:{:2f}'.format(ACC.mean()*100))
            print('***Class# Low****')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[1], epochfp[1], epochtn[1], epochfn[1], recall[1], specificity[1] ))
            print('***Class# Medium***')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[0], epochfp[0], epochtn[0], epochfn[0], recall[0], specificity[0] ))
            print('***Class# High****')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[2], epochfp[2], epochtn[2], epochfn[2], recall[2], specificity[2] ))
            print('____________________________________________________________________________________')
            history["%s_loss"%(phase)].append(epoch_loss)
            history["%s_acc"%(phase)].append((epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0)
            # deep copy the model
            logger.debug('____________________________________________________________________________________')
            logger.debug('fold_'+str(fold))
            logger.debug('{} Loss: {:.3f} R2: {:.3f} Acc: {:.3f} , pearson {:3f}'.format(phase, epoch_loss, epoch_r2,  epoch_acc, corr))
            logger.debug('*** Class Accuracy***')
            logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(epoch_acc_all[1], epoch_acc_all[0], epoch_acc_all[2] ))
            logger.debug('Mean Accuracy:{:2f}'.format(ACC.mean()*100))
            logger.debug('***Class# Low****')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[1], epochfp[1], epochtn[1], epochfn[1], recall[1], specificity[1] ))
            logger.debug('***Class# Medium***')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[0], epochfp[0], epochtn[0], epochfn[0], recall[0], specificity[0] ))
            logger.debug('***Class# High****')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[2], epochfp[2], epochtn[2], epochfn[2], recall[2], specificity[2] ))
            logger.debug('____________________________________________________________________________________')
            
                
                
                
            if phase == 'val' and best_acc < (epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0:
                best_acc = (epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0
                btp, bfp, btn, bfn, bsen, bspec, bcorr, bp,brho, bsp, bacc_all, b_r2, b_npv, b_ppv, b_kappa=epochtp, epochfp, epochtn, epochfn, recall, specificity, corr, p, rho, sp, epoch_acc_all,epoch_r2, epoch_npv, epoch_ppv, epoch_kappa
                best_model_wts = copy.deepcopy(model.state_dict())
                
        early_stopping(-history["val_acc"][-1], model)
        
        if early_stopping.early_stop:
            print("Early stopping")
            break     
    print('fold_'+str(fold))
    print('Best val Acc: {:4f}, R2: {:4f}'.format(best_acc, b_r2))
    print('*** Class Accuracy***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(bacc_all[1], bacc_all[0], bacc_all[2] ))
    print('*** Class NPV***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_npv[1], b_npv[0], b_npv[2] ))
    print('*** Class PPV***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_ppv[1], b_ppv[0], b_ppv[2] ))
    print('Best (sen| spec|corr|kappa): {:1f}, {:1f},{:2f}, {:2f}, {:2f},{:2f},  {:2f},,  {:2f}'
          .format(bsen[1],bsen[0],bsen[2], bspec[1],bspec[0],bspec[2], bcorr, b_kappa))
    
    logger.debug('fold_'+str(fold))
    logger.debug('Best val Acc: {:4f}, R2: {:4f}'.format(best_acc, b_r2))
    logger.debug('*** Class Accuracy***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(bacc_all[1], bacc_all[0], bacc_all[2] ))
    logger.debug('*** Class NPV***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_npv[1], b_npv[0], b_npv[2] ))
    logger.debug('*** Class PPV***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_ppv[1], b_ppv[0], b_ppv[2] ))
    logger.debug('Best (sen| spec|corr|kappa): {:1f}, {:1f},{:2f}, {:2f}, {:2f},{:2f},  {:2f},,  {:2f}'
          .format(bsen[1],bsen[0],bsen[2], bspec[1],bspec[0],bspec[2], bcorr, b_kappa))
   
    # load best model weights
    model.load_state_dict(best_model_wts)
    

    train_acc=history['train_acc']
    train_acc=[i*100 for i in train_acc]
    train_loss=history['train_loss']
    
    val_acc=history['val_acc']
    val_acc=[i*100 for i in val_acc]
    val_loss=history['val_loss']
    
    # test_acc=history['test_acc']
    # test_acc=[i.cpu().detach().numpy()*100 for i in test_acc]
    # test_loss=history['test_loss']
    
    # plotting_(epoch,train_acc[:epoch], train_loss[:epoch], val_acc[:epoch], val_loss[:epoch]) #sort this out later
    # plotting_(epoch,train_acc[:epoch], train_loss[:epoch], test_acc[:epoch], test_loss[:epoch]) #sort this out later
    data_out = {}
    data_out['history'] = history
    data_out['best_acc'] = best_acc
    data_out['bsen'] = bsen
    data_out['bspec'] = bspec
    data_out['bcorr'] = bcorr
    data_out['epoch'] = epoch
    data_out['bp'] = bp
    data_out['brho'] = brho
    data_out['bsp'] = bsp
    data_out['brho'] = brho
    data_out['bsp'] = bsp
    data_out['details'] = details
    data_out['bacc_all'] = bacc_all
    data_out['btp'] = btp
    data_out['bfp'] = bfp
    data_out['btn'] = btn
    data_out['bfp'] = bfp
    data_out['btn'] = btn
    data_out['bfn'] = bfn
    data_out['b_r2'] = b_r2
    data_out['b_npv'] = b_npv
    data_out['b_ppv'] = b_ppv
    data_out['b_kappa'] = b_kappa
    return model, data_out

def train_model_reg(model, criterion_aac_score, criterion_L1A, criterion_L1P, criterion_L2A, criterion_L2P, criterion_L3A, criterion_L3P, criterion_L4A, criterion_L4P, optimizer, scheduler, train_loader, val_loader, device, loss_option, logger, fold, num_epochs=25, patience = 50):
    dataloaders = {}
    dataloaders['train'] = train_loader
    dataloaders['val'] = val_loader
    since = time.time()
    patience=patience
    
    
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    history = {'train_loss':[], 'train_acc':[], 'val_loss':[], 'val_acc':[], 'test_loss':[], 'test_acc':[]}
    bfn=0.0
    best_precision=0.0
    best_recall=0.0
    best_auc =0.0
    best_specificity=0.0
    flag=0
    flag2=0
    flag3=0
    corr_loss=0.0
    btp=0
    bfp=0 
    btn=0
    bfn=0
    bsen=0.0 
    bspec=0.0
    bauc=0.0
    bcorr=0.0
    bp=0.0
    brho=0.0
    bsp=0.0
    bacc_all=0.0
    train_losses = []
    # to track the validation loss as the model trains
    valid_losses = []
    # to track the average training loss per epoch as the model trains
    avg_train_losses = []
    # to track the average validation loss per epoch as the model trains
    avg_valid_losses = [] 
    
    # details = {'train_id':[], 'val_id':[],'test_id':[],'train_pred':[], 'val_pred':[], 'test_pred':[], 'train_gt':[], 'val_gt':[], 'test_gt':[]}
    details = {'train_id':[], 'val_id':[],'test_id':[],'train_pred':[], 'val_pred':[], 'test_pred':[], 'train_gt':[],'val_gt':[], 'test_gt':[], 'train_gt_gran':[], 'val_gt_gran':[], 'test_gt_gran':[] , 'train_pred_gran':[], 'val_pred_gran':[], 'test_pred_gran':[]}

    # initialize the early_stopping object
    early_stopping = EarlyStopping(patience=patience, verbose=True)
    flag=0
    for epoch in tqdm(range(num_epochs)):
        # print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        # print('-' * 10)
        if epoch%2==0:
            option=['train','val']#,'train2','val']
        else:
            option=['train','val']
        # Each epoch has a training and validation phase
        
        for phase in option:
            if phase == 'train':
                phase='train'

                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

            running_loss = 0.0
            runningr2 = 0.0
                                    
            running_ppv=0.0
            running_npv=0.0
            running_kappa=0.0
            running_corrects = 0
            runningtp=[0,0,0]
            runningfp=[0,0,0]
            runningtn=[0,0,0]
            runningfn=[0,0,0]
            running_acc=[0.0,0.0, 0.0]

            # Iterate over data.
            count=0
            
    
            l_c=[]
            o_c=[]

            for batch_,(inputs, labels, name, captions_target) in enumerate(dataloaders[phase]):

                inputs = inputs.to(device)
                labels = labels.to(device)
                captions_target = captions_target.to(device)

                labels_class = labels.cpu().detach().numpy().copy()

                labels1 = (labels_class*24) >= 6
                labels2 = (labels_class*24) < 2

                labels1 = labels1*2
                labels2 = labels2*1
                labels3 = labels_class*0

                labels_class = labels1+labels2+labels3

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    outputs_,_ = model(inputs)
                    # outputs_ = model(inputs)
                    # outputs = outputs[:, 0]
                    # if isinstance(outputs, tuple):
                    #     outputs = outputs[0][:][0]
                    #_, preds = torch.max(outputs, 1)

                    # weight=weighted_mse_loss(wts,labels)
                    # weight=weight.to(device)
                    # loss=torch.sum(weight * (outputs - labels) ** 2)

                    # outputs_max_values =outputs_[1].max(dim=-1).indices.cpu().detach().numpy().copy()
                    
                    
                    # loss_L1A =  criterion_L1A(outputs_[1][:,0,:],captions_target[:,0])
                    # loss_L1P =  criterion_L1P(outputs_[1][:,1,:],captions_target[:,1])
                    
                    # loss_L2A =  criterion_L2A(outputs_[1][:,2,:],captions_target[:,2])
                    # loss_L2P =  criterion_L2P(outputs_[1][:,3,:],captions_target[:,3])
                    
                    # loss_L3A =  criterion_L3A(outputs_[1][:,4,:],captions_target[:,4])
                    # loss_L3P =  criterion_L3P(outputs_[1][:,5,:],captions_target[:,5])
                    
                    # loss_L4A =  criterion_L4A(outputs_[1][:,6,:],captions_target[:,6])
                    # loss_L4P =  criterion_L4P(outputs_[1][:,7,:],captions_target[:,7])        
                    
                    # output_gran = outputs_[1].softmax(2).argmax(2).detach().cpu()
                    # outputs = (outputs[1].softmax(2).argmax(2).sum(1)/24).unsqueeze(1)
                    captions_total = (captions_target.sum(1)/24).unsqueeze(1)
                    
                    captions_L1A = (captions_target[:,0]/3).unsqueeze(1)
                    captions_L1P = (captions_target[:,1]/3).unsqueeze(1)
                    
                    captions_L2A = (captions_target[:,2]/3).unsqueeze(1)
                    captions_L2P = (captions_target[:,3]/3).unsqueeze(1)
                    
                    captions_L3A = (captions_target[:,4]/3).unsqueeze(1)
                    captions_L3P = (captions_target[:,5]/3).unsqueeze(1)
                    
                    captions_L4A = (captions_target[:,6]/3).unsqueeze(1)
                    captions_L4P = (captions_target[:,7]/3).unsqueeze(1)
                    
                    loss_aac = criterion_aac_score(outputs_[:,0].unsqueeze(-1),captions_total)
                    
                    loss_L1A = criterion_L1A(outputs_[:,1].unsqueeze(-1),captions_L1A)
                    loss_L1P = criterion_L1P(outputs_[:,2].unsqueeze(-1),captions_L1P)
                    
                    loss_L2A = criterion_L2A(outputs_[:,3].unsqueeze(-1),captions_L2A)
                    loss_L2P = criterion_L2P(outputs_[:,4].unsqueeze(-1),captions_L2P)
                    
                    loss_L3A = criterion_L3A(outputs_[:,5].unsqueeze(-1),captions_L3A)
                    loss_L3P = criterion_L3P(outputs_[:,6].unsqueeze(-1),captions_L3P)
                    
                    loss_L4A = criterion_L4A(outputs_[:,7].unsqueeze(-1),captions_L4A)
                    loss_L4P = criterion_L4P(outputs_[:,8].unsqueeze(-1),captions_L4P)
                    
                    loss_aac_gran = loss_L1A + loss_L1P + loss_L2A + loss_L2P + loss_L3A + loss_L3P + loss_L4A + loss_L4P
                    
                    loss = loss_aac + loss_aac_gran
                    # outputs_1 = outputs[1].squeeze(1)
                    # output_gran = []
                    output_gran = outputs_[:,1:]
                    output_gran_ = (output_gran*3/24).cuda()
                    outputs_aac = outputs_[:, 0].cuda()
                    outputs = (output_gran_.sum(1) + outputs_aac)/2
                        
                    # loss = criterion(outputs*24, labels*24)
                        
                        
                    r2=r2_score(outputs, labels)
                    
                    
                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()
                        
                        
                        
                preds=outputs.cpu().detach().numpy().copy()
                
                
                preds1= (preds*24)>= 6
                preds2= (preds*24)<2

                preds1=preds1*2
                preds2=preds2*1
                preds3=preds*0
                
                
                preds = preds1+preds2+preds3
                

                
                cnf_matrix = confusion_matrix(preds, torch.from_numpy(labels_class),labels=[0,1, 2])
                kappa= cohen_kappa_score(preds, torch.from_numpy(labels_class),labels=[0,1, 2])
                np.set_printoptions(precision=2)
                # plt.figure()
                # plot_confusion_matrix(cnf_matrix, classes=['med', 'low', 'high'],
                #                       title='Confusion matrix, without normalization')
                
                #############################################################################
                # https://towardsdatascience.com/multi-class-classification-extracting-performance-metrics-from-the-confusion-matrix-b379b427a872
                FP = cnf_matrix.sum(axis=0) - np.diag(cnf_matrix) 
                FN = cnf_matrix.sum(axis=1) - np.diag(cnf_matrix)
                TP = np.diag(cnf_matrix)
                TN = cnf_matrix.sum() - (FP + FN + TP)
                FP = FP.astype(float)
                FN = FN.astype(float)
                TP = TP.astype(float)
                TN = TN.astype(float)
                
                # Sensitivity, hit rate, recall, or true positive rate
                TPR = TP/(TP+ 0.000000000000000001+FN + 0.000000000000000001)
                # Specificity or true negative rate
                TNR = TN/(TN+ 0.000000000000000001+FP + 0.000000000000000001) 
                
                
                # Precision or positive predictive value
                PPV = TP/(TP+ 0.000000000000000001+FP+ 0.000000000000000001)
                # Negative predictive value
                NPV = TN/(TN+ 0.000000000000000001+FN+ 0.000000000000000001)
                running_kappa+=kappa
                # # Fall out or false positive rate
                # FPR = FP/(FP+TN)
                # # False negative rate
                # FNR = FN/(TP+FN)
                # # False discovery rate
                # FDR = FP/(TP+FP)
                # # Overall accuracy for each class
                ACC = (TP+TN)/(TP+FP+FN+TN)
                #######################################################################################################

                l_c+=list(labels.cpu().detach().numpy())
                o_c+=list(outputs.cpu().detach().numpy())
                #auc=0.1
                
                
                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(torch.from_numpy(preds) == torch.from_numpy(labels_class))
                runningtp+=TP
                runningfp+=FP
                runningtn+=TN
                runningfn+=FN
                running_acc+=ACC
                runningr2+=r2
                
                running_ppv+=PPV
                running_npv+=NPV
                
                
                count+=len(labels_class)
                details["%s_id"%(phase)].append(name)
                details["%s_pred"%(phase)].extend(outputs.cpu().detach().numpy())
                details["%s_gt"%(phase)].extend(labels.cpu().detach().numpy())
                details["%s_gt_gran"%(phase)].extend(captions_target.cpu().detach().numpy())
                details["%s_pred_gran"%(phase)].extend(3*output_gran.cpu().detach().numpy())        
            # if phase=='train':          
            #     if scheduler:
            #         scheduler.step()
                
                
            epoch_loss = running_loss / count
            epoch_r2 = runningr2 / count
            epoch_acc = (running_corrects.double() / count) *100
            epoch_acc_all=(running_acc / (batch_+1)) *100
            
            
            epoch_ppv=(running_ppv / (batch_+1)) *100
            epoch_npv=(running_npv / (batch_+1)) *100
            epoch_kappa=(running_kappa / (batch_+1)) *100
 
            epochtp=runningtp
            epochfp=runningfp
            epochtn=runningtn
            epochfn=runningfn




            epochauc=0.1#roc_auc_score(l_c, o_c)
            #precision=(epochtp/(epochtp+epochfp+0.00001)) *100
            recall=(epochtp/(epochtp+epochfn+0.00001)) *100
            specificity=(epochtn/(epochtn+epochfp+0.00001)) *100
            #corr, _ = pearsonr(l_c, o_c)
            corr, p = scipy.stats.pearsonr(l_c, o_c)
            if phase=='train':
                corr_loss=corr
            rho, sp = scipy.stats.spearmanr(l_c, o_c)
            print('____________________________________________________________________________________')
            print('fold_'+str(fold))
            print('{} Loss: {:.3f} R2: {:.3f} Acc: {:.3f} , pearson {:3f}'.format(phase, epoch_loss, epoch_r2,  epoch_acc, corr))
            print('*** Class Accuracy***')
            print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(epoch_acc_all[1], epoch_acc_all[0], epoch_acc_all[2] ))
            print('Mean Accuracy:{:2f}'.format(ACC.mean()*100))
            print('***Class# Low****')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[1], epochfp[1], epochtn[1], epochfn[1], recall[1], specificity[1] ))
            print('***Class# Medium***')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[0], epochfp[0], epochtn[0], epochfn[0], recall[0], specificity[0] ))
            print('***Class# High****')
            print('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[2], epochfp[2], epochtn[2], epochfn[2], recall[2], specificity[2] ))
            print('____________________________________________________________________________________')
            history["%s_loss"%(phase)].append(epoch_loss)
            history["%s_acc"%(phase)].append((epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0)
            # deep copy the model
            logger.debug('____________________________________________________________________________________')
            logger.debug('fold_'+str(fold))
            logger.debug('{} Loss: {:.3f} R2: {:.3f} Acc: {:.3f} , pearson {:3f}'.format(phase, epoch_loss, epoch_r2,  epoch_acc, corr))
            logger.debug('*** Class Accuracy***')
            logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(epoch_acc_all[1], epoch_acc_all[0], epoch_acc_all[2] ))
            logger.debug('Mean Accuracy:{:2f}'.format(ACC.mean()*100))
            logger.debug('***Class# Low****')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[1], epochfp[1], epochtn[1], epochfn[1], recall[1], specificity[1] ))
            logger.debug('***Class# Medium***')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[0], epochfp[0], epochtn[0], epochfn[0], recall[0], specificity[0] ))
            logger.debug('***Class# High****')
            logger.debug('(tp, fp, tn, fn, sensitivity, specificity):  {:2f}, {:2f}, {:2f}, {:2f}, {:2f}, {:2f}'.format( epochtp[2], epochfp[2], epochtn[2], epochfn[2], recall[2], specificity[2] ))
            logger.debug('____________________________________________________________________________________')
            
                
                
                
            if phase == 'val' and best_acc < (epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0:
                best_acc = (epoch_acc_all[1]+ epoch_acc_all[0]+ epoch_acc_all[2])/3.0
                btp, bfp, btn, bfn, bsen, bspec, bcorr, bp,brho, bsp, bacc_all, b_r2, b_npv, b_ppv, b_kappa=epochtp, epochfp, epochtn, epochfn, recall, specificity, corr, p, rho, sp, epoch_acc_all,epoch_r2, epoch_npv, epoch_ppv, epoch_kappa
                best_model_wts = copy.deepcopy(model.state_dict())
                
        early_stopping(-history["val_acc"][-1], model)
        
        if early_stopping.early_stop:
            print("Early stopping")
            break     
    print('fold_'+str(fold))
    print('Best val Acc: {:4f}, R2: {:4f}'.format(best_acc, b_r2))
    print('*** Class Accuracy***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(bacc_all[1], bacc_all[0], bacc_all[2] ))
    print('*** Class NPV***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_npv[1], b_npv[0], b_npv[2] ))
    print('*** Class PPV***')
    print('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_ppv[1], b_ppv[0], b_ppv[2] ))
    print('Best (sen| spec|corr|kappa): {:1f}, {:1f},{:2f}, {:2f}, {:2f},{:2f},  {:2f},,  {:2f}'
          .format(bsen[1],bsen[0],bsen[2], bspec[1],bspec[0],bspec[2], bcorr, b_kappa))
    
    logger.debug('fold_'+str(fold))
    logger.debug('Best val Acc: {:4f}, R2: {:4f}'.format(best_acc, b_r2))
    logger.debug('*** Class Accuracy***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(bacc_all[1], bacc_all[0], bacc_all[2] ))
    logger.debug('*** Class NPV***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_npv[1], b_npv[0], b_npv[2] ))
    logger.debug('*** Class PPV***')
    logger.debug('(Low, moderate, high):  {:2f}, {:2f}, {:2f}'.format(b_ppv[1], b_ppv[0], b_ppv[2] ))
    logger.debug('Best (sen| spec|corr|kappa): {:1f}, {:1f},{:2f}, {:2f}, {:2f},{:2f},  {:2f},,  {:2f}'
          .format(bsen[1],bsen[0],bsen[2], bspec[1],bspec[0],bspec[2], bcorr, b_kappa))
   
    # load best model weights
    model.load_state_dict(best_model_wts)
    

    train_acc=history['train_acc']
    train_acc=[i*100 for i in train_acc]
    train_loss=history['train_loss']
    
    val_acc=history['val_acc']
    val_acc=[i*100 for i in val_acc]
    val_loss=history['val_loss']
    
    # test_acc=history['test_acc']
    # test_acc=[i.cpu().detach().numpy()*100 for i in test_acc]
    # test_loss=history['test_loss']
    
    # plotting_(epoch,train_acc[:epoch], train_loss[:epoch], val_acc[:epoch], val_loss[:epoch]) #sort this out later
    # plotting_(epoch,train_acc[:epoch], train_loss[:epoch], test_acc[:epoch], test_loss[:epoch]) #sort this out later
    data_out = {}
    data_out['history'] = history
    data_out['best_acc'] = best_acc
    data_out['bsen'] = bsen
    data_out['bspec'] = bspec
    data_out['bcorr'] = bcorr
    data_out['epoch'] = epoch
    data_out['bp'] = bp
    data_out['brho'] = brho
    data_out['bsp'] = bsp
    data_out['brho'] = brho
    data_out['bsp'] = bsp
    data_out['details'] = details
    data_out['bacc_all'] = bacc_all
    data_out['btp'] = btp
    data_out['bfp'] = bfp
    data_out['btn'] = btn
    data_out['bfp'] = bfp
    data_out['btn'] = btn
    data_out['bfn'] = bfn
    data_out['b_r2'] = b_r2
    data_out['b_npv'] = b_npv
    data_out['b_ppv'] = b_ppv
    data_out['b_kappa'] = b_kappa
    return model, data_out


def predict(model, val_loader, device):
    since = time.time()  
    
    phase = 'val'
    
    for epoch in tqdm(range(1)):
        # print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        # print('-' * 10)
        
            model.eval()   # Set model to evaluate mode
            dicta = {'name': [],
                     'cummulative_score':[],
                     'granular_sum':[],
                     'average_cum_score':[],
                     'L1A_pred':[],
                     'L1P_pred':[],
                     'L2A_pred':[],
                     'L2P_pred':[],
                     'L3A_pred':[],
                     'L3P_pred':[],
                     'L4A_pred':[],
                     'L4P_pred':[]}
            for batch_,(inputs, name) in enumerate(tqdm(val_loader)):


                inputs = inputs.to(device)
                # captions_target = captions_target.to(device)

                with torch.set_grad_enabled(phase == 'train'):
                    outputs_ = model(inputs)
                    
                    outputs_max_values =outputs_[1].max(dim=-1).indices.cpu().detach().numpy().copy()
                    output_gran = outputs_[1].softmax(2).argmax(2).detach().cpu()
                    # outputs = (outputs[1].softmax(2).argmax(2).sum(1)/24).unsqueeze(1)
                    # captions_1 = (captions_target.sum(1)/24).unsqueeze(1)
                    
                    output_gran_ = output_gran
                    outputs_aac = (outputs_[0][:, 0]*24).cpu()
                    outputs = (output_gran_.sum(1) + outputs_aac)/2
   
                    # data['granular_score'].extend(outputs_max_values)
                    dicta['name'].extend(name)
                    dicta['cummulative_score'].extend(outputs_aac.numpy())
                    dicta['average_cum_score'].extend(outputs.numpy())
                    dicta['granular_sum'].extend(output_gran_.sum(1).numpy())
                    dicta['L1A_pred'].extend(outputs_max_values[:,0])
                    dicta['L1P_pred'].extend(outputs_max_values[:,1])
                    dicta['L2A_pred'].extend(outputs_max_values[:,2])
                    dicta['L2P_pred'].extend(outputs_max_values[:,3])
                    dicta['L3A_pred'].extend(outputs_max_values[:,4])
                    dicta['L3P_pred'].extend(outputs_max_values[:,5])
                    dicta['L4A_pred'].extend(outputs_max_values[:,6])
                    dicta['L4P_pred'].extend(outputs_max_values[:,7])
                    
            df2 = pd.DataFrame(dicta)


                
    return df2