import torch
import torch.nn as nn
from .efficient_encoder import *
from einops import rearrange
import numbers
import math
from torch.nn import functional as F
##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma+1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma+1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        # h, w = x.shape[-2:]
        return self.body(x)

class LayerNorm_Channel(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm_Channel, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, hw, c = x.shape
        x = rearrange(x, 'b c (h w) -> b c h w', h=int(math.sqrt(c)), w = int(math.sqrt(c)))
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        x = rearrange(x, 'b c h w -> b c (h w)', h=int(math.sqrt(c)), w= int(math.sqrt(c)))
        return x

class Channel_FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(Channel_FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x

##########################################################################
class Channel_Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Channel_Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim*3, kernel_size=1, bias=bias)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        


    def forward(self, x):
        b,c,h,w = x.shape

        qkv = self.qkv(x)
        q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out

class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q = nn.Linear(dim,dim, bias=False)
        self.k = nn.Linear(dim,dim, bias=False)
        self.v = nn.Linear(dim,dim, bias=False)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        # self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        # x = rearrange(x, 'b c h w -> b c (h w)')
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b feature seq -> b seq feature')
        k = rearrange(k, 'b feature seq -> b seq feature')
        v = rearrange(v, 'b feature seq -> b seq feature')

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
       
        out = rearrange(out, 'b seq feature -> b feature seq ')
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out

## Multi-DConv Head Transposed Self-Attention (MDTA)
# class HiLo_Attention(nn.Module):
#     def __init__(self, dim, num_heads, bias, channels, head_size):
#         super(HiLo_Attention, self).__init__()
#         self.num_heads = num_heads
#         self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
#         self.head_size = head_size
#         # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
#         self.q_Hi = nn.Linear(head_size,head_size, bias=False)
#         self.k_Hi = nn.Linear(head_size,head_size, bias=False)
#         self.v_Hi = nn.Linear(head_size,head_size, bias=False)
#         self.q_Lo = nn.Linear(head_size,head_size, bias=False)
#         self.k_Lo = nn.Linear(head_size,head_size, bias=False)
#         self.v_Lo = nn.Linear(head_size,head_size, bias=False)
        
#         self.downsample = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
#         self.convTranspose = nn.ConvTranspose2d(channels, channels, 2, 2)
#         # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
#         self.project_out = nn.Conv2d(channels, channels, kernel_size=1, bias=bias)
#         # self.project_out = nn.Linear(dim,dim, bias=False)
        


#     def forward(self, x):
#         # b,c,h,w = x.shape
#         # qkv = self.qkv_dwconv(self.qkv(x))
#         # x1=x
#         b,c,h,w = x.shape
#         x_Hi = x
#         x_Lo = self.downsample(x)
        
#         b_l, c_l, h_l, w_l = x_Lo.shape
        
#         x_Hi = rearrange(x_Hi, 'b c h w -> b c (h w)')
#         x_Hi = rearrange(x_Hi, 'b c (hw head) -> b hw c  head', head = self.head_size)
#         q_Hi = self.q_Hi(x_Hi)
#         k_Hi = self.k_Hi(x_Hi)
#         v_Hi = self.v_Hi(x_Hi)
#         # q,k,v = qkv.chunk(3, dim=1)   
        
#         q_Hi = rearrange(q_Hi, 'b head c  hw -> b head hw c')
#         k_Hi = rearrange(k_Hi, 'b head c  hw -> b head hw c')
#         v_Hi = rearrange(v_Hi, 'b head c  hw -> b head hw c')

#         q_Hi = torch.nn.functional.normalize(q_Hi, dim=-1)
#         k_Hi = torch.nn.functional.normalize(k_Hi, dim=-1)

#         attn_Hi = (q_Hi @ k_Hi.transpose(-2, -1)) * self.temperature
#         attn_Hi = attn_Hi.softmax(dim=-1)

#         out_Hi = (attn_Hi @ v_Hi)
        
#         out_Hi = rearrange(out_Hi, 'b head hw c -> b head c hw')
#         out_Hi = rearrange(out_Hi, 'b hw c head -> b c (hw head) ', head = self.head_size)
#         out_Hi = rearrange(out_Hi, 'b c (h w) -> b c h w ', h = h, w = w)
        
                
        
#         x_Lo = rearrange(x_Lo, 'b c h w -> b c (h w)')
#         x_Lo = rearrange(x_Lo, 'b c (hw head) -> b hw c  head ', head = self.head_size)
#         q_Lo = self.q_Lo(x_Lo)
#         k_Lo = self.k_Lo(x_Lo)
#         v_Lo = self.v_Lo(x_Lo)
#         # q,k,v = qkv.chunk(3, dim=1)   
        
#         q_Lo = rearrange(q_Lo, 'b head c  hw -> b head hw c')
#         k_Lo = rearrange(k_Lo, 'b head c  hw -> b head hw c')
#         v_Lo = rearrange(v_Lo, 'b head c  hw -> b head hw c')

#         q_Lo = torch.nn.functional.normalize(q_Lo, dim=-1)
#         k_Lo = torch.nn.functional.normalize(k_Lo, dim=-1)

#         attn_Lo = (q_Lo @ k_Lo.transpose(-2, -1)) * self.temperature
#         attn_Lo = attn_Lo.softmax(dim=-1)

#         out_Lo = (attn_Lo @ v_Lo)
        
#         out_Lo = rearrange(out_Lo, 'b head hw c -> b head c hw')
#         out_Lo = rearrange(out_Lo, 'b hw c head -> b c (hw head) ', head = self.head_size)
#         out_Lo = rearrange(out_Lo, 'b c (h w) -> b c h w ', h = h_l, w = w_l)
        
#         out_Lo = self.convTranspose(out_Lo)
        
#         out = out_Hi + out_Lo
        
#         # out = rearrange(out, 'b c (h w) -> b c h w', h = h, w = w)
        
#         out = self.project_out(out)
#         # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
#         return out    

class HiLo_Attention2(nn.Module):
    def __init__(self, dim, num_heads, bias, channels, head_size):
        super(HiLo_Attention2, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.head_size = head_size
        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        # self.q_Hi = nn.Linear(head_size,head_size, bias=False)        
        # self.k_Hi = nn.Linear(head_size,head_size, bias=False)
        # self.v_Hi = nn.Linear(head_size,head_size, bias=False)
        # self.q_Lo = nn.Linear(head_size,head_size, bias=False)
        # self.k_Lo = nn.Linear(head_size,head_size, bias=False)
        # self.v_Lo = nn.Linear(head_size,head_size, bias=False)
        self.q_Hi = nn.Conv2d(channels, channels, 1)
        self.k_Hi = nn.Conv2d(channels, channels, 1)
        self.v_Hi = nn.Conv2d(channels, channels, 1)
        self.q_Lo = nn.Conv2d(channels, channels, 1)
        self.k_Lo = nn.Conv2d(channels, channels, 1)
        self.v_Lo = nn.Conv2d(channels, channels, 1)
        
        self.downsample = nn.AvgPool2d(kernel_size=2,stride=2,padding=0)
        self.convTranspose = nn.ConvTranspose2d(channels, channels, 2, 2)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(channels, channels, kernel_size=1, bias=bias)
        # self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        b,c,h,w = x.shape
        x_Hi = x
        x_Lo = self.downsample(x)
        
        # b_l, c_l, h_l, w_l = x_Lo.shape
        

        q_Hi = self.q_Hi(x_Hi)
        k_Hi = self.k_Hi(x_Hi)
        v_Hi = self.v_Hi(x_Hi)
        # q,k,v = qkv.chunk(3, dim=1)   
        q_Hi = rearrange(q_Hi, 'b c h w -> b c (h w)')
        k_Hi = rearrange(k_Hi, 'b c h w -> b c (h w)')
        v_Hi = rearrange(v_Hi, 'b c h w -> b c (h w)')
        
        q_Hi = rearrange(q_Hi, 'b c (hw head) -> b head hw c', head = self.head_size)    
        k_Hi = rearrange(k_Hi, 'b c (hw head) -> b head hw c', head = self.head_size)  
        v_Hi = rearrange(v_Hi, 'b c (hw head) -> b head hw c', head = self.head_size)  
        
        # q_Hi = rearrange(q_Hi, 'b head c  hw -> b head hw c')
        # k_Hi = rearrange(k_Hi, 'b head c  hw -> b head hw c')
        # v_Hi = rearrange(v_Hi, 'b head c  hw -> b head hw c')

        q_Hi = torch.nn.functional.normalize(q_Hi, dim=-1)
        k_Hi = torch.nn.functional.normalize(k_Hi, dim=-1)

        attn_Hi = (q_Hi @ k_Hi.transpose(-2, -1)) * self.temperature
        attn_Hi = attn_Hi.softmax(dim=-1)

        out_Hi = (attn_Hi @ v_Hi)
        
        # out_Hi = rearrange(out_Hi, 'b head hw c -> b head c hw')
        # out_Hi = rearrange(out_Hi, 'b hw c head -> b c (hw head) ', head = self.head_size)
        # out_Hi = rearrange(out_Hi, 'b c (h w) -> b c h w ', h = h, w = w)
        
        q_Lo = self.q_Lo(x_Hi)
        k_Lo = self.k_Lo(x_Lo)
        v_Lo = self.v_Lo(x_Lo)
        # q,k,v = qkv.chunk(3, dim=1)   
        q_Lo = rearrange(q_Lo, 'b c h w -> b c (h w)')
        k_Lo = rearrange(k_Lo, 'b c h w -> b c (h w)')
        v_Lo = rearrange(v_Lo, 'b c h w -> b c (h w)')
        
        q_Lo = rearrange(q_Lo, 'b c (hw head) -> b head hw c', head = self.head_size)    
        k_Lo = rearrange(k_Lo, 'b c (hw head) -> b head hw c', head = self.head_size)  
        v_Lo = rearrange(v_Lo, 'b c (hw head) -> b head hw c', head = self.head_size)  
        
        # q_Hi = rearrange(q_Hi, 'b head c  hw -> b head hw c')
        # k_Hi = rearrange(k_Hi, 'b head c  hw -> b head hw c')
        # v_Hi = rearrange(v_Hi, 'b head c  hw -> b head hw c')

        q_Lo = torch.nn.functional.normalize(q_Lo, dim=-1)
        k_Lo = torch.nn.functional.normalize(k_Lo, dim=-1)

        attn_Lo = (q_Lo @ k_Lo.transpose(-2, -1)) * self.temperature
        attn_Lo = attn_Lo.softmax(dim=-1)        
        
        out_Lo = (attn_Lo @ v_Lo)

        
        # out_Lo = self.convTranspose(out_Lo)
        
        out = out_Hi + out_Lo
                
        out = rearrange(out, 'b head hw c -> b c head hw')
        out = rearrange(out, 'b c head hw -> b c (head hw) ', head = self.head_size)
        # out_Lo = rearrange(out_Lo, 'b c (h w) -> b c h w ', h = h, w = w)
        out = rearrange(out, 'b c (h w) -> b c h w', h = h, w = w)
        
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out    

class Channel_Transformer(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(Channel_Transformer, self).__init__()

        self.norm1 = LayerNorm_Channel(dim, LayerNorm_type)
        self.attn = Channel_Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm_Channel(dim, LayerNorm_type)
        self.ffn = Channel_FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))

        return x
    
class TransformerBlock(nn.Module):
    def __init__(self, dim=None, head_size=10, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(TransformerBlock, self).__init__()
        self.dim = dim
        self.head_size = head_size
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        # x = rearrange(x, 'b c (h w)-> b c h w ', h = h, w = w)
        x = x + self.attn(x)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x

class HiLoTransformerBlock(nn.Module):
    def __init__(self, dim=None, head_size=10, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(HiLoTransformerBlock, self).__init__()
        self.dim = dim
        self.head_size = head_size
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = HiLo_Attention2(dim, num_heads, bias, channels, self.head_size)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        x = rearrange(x, 'b c (h w)-> b c h w ', h = h, w = w)
        x = x + self.attn(x)
        x = rearrange(x, 'b c h w-> b c (h w) ', h = h, w = w)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x

class EFFM(nn.Module):
    def __init__(self, x1_channels = None, x2_channels = None):
        super(EFFM, self).__init__()
        self.conv1 = nn.Conv2d(x1_channels+x2_channels, x2_channels, 1)
        self.channel_transformer = Channel_Transformer(dim=x2_channels, num_heads = 2, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.down =  nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
    def forward(self, x1 , x2):
        x = torch.cat([x1, x2], 1)
        x = self.conv1(x)
        x = self.channel_transformer(x)
        x = self.down(x)
        return x

class model_Hilo(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = get_efficientEncoder_b3(out_channels=2, concat_input=True, pretrained=True)
        self.conv_1 = nn.Conv2d(in_channels=1536, out_channels=256, kernel_size=1, bias=False)
        # self.conv_1_1 = nn.Conv2d(in_channels=512, out_channels=512, kernel_size=1, bias=False)
        # self.conv_2 = nn.Conv2d(in_channels=192, out_channels=256, kernel_size=1, bias=False)
        # self.conv_3 = nn.Conv2d(in_channels=48, out_channels=96, kernel_size=1, bias=False)
        # self.conv_4 = nn.Conv2d(in_channels=64, out_channels=48, kernel_size=1, bias=False)
        # self.conv_5 = nn.Conv2d(in_channels=24, out_channels=32, kernel_size=1, bias=False)
        
        # self.conv_4 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=1, bias=False)
        
        self.t_s_block1 = TransformerBlock(dim=10*10, head_size=10, channels=256, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.t_s_block2 = TransformerBlock(dim=10*10, head_size=10, channels=512, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        self.t_hilo_block2 = HiLoTransformerBlock(dim=20*20, channels=96, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.t_hilo_block3 = HiLoTransformerBlock(dim=40*40, channels=48, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.t_hilo_block4 = HiLoTransformerBlock(dim=80*80, channels=32, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.t_hilo_block5 = HiLoTransformerBlock(dim=160*160, channels=24, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        # self.down_5 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_4 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.down_3 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.down_2 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_1 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        
        self.effm32 = EFFM(x1_channels = 48, x2_channels = 96)
        self.effm21 = EFFM(x1_channels = 96, x2_channels = 256)
        
        self._avg_pooling = nn.AdaptiveAvgPool2d(1)
        # self.linear_layers = nn.Sequential(
        #         nn.BatchNorm1d(num_features=512),    
        #         nn.Linear(512, 512),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(512),
        #         nn.Linear(512, 128),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(num_features=128),
        #         nn.Dropout(0.4),
        #         nn.Linear(128, 1),
        #     )
        # self.linear_layers2 = nn.Sequential(
        #         nn.BatchNorm1d(num_features=512),    
        #         nn.Linear(512, 512),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(512),
        #         nn.Linear(512, 128),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(num_features=128),
        #         nn.Dropout(0.4),
        #         nn.Linear(128, 32),
        #     )
        self.linear_layers = nn.Sequential(
                nn.BatchNorm1d(256),
                nn.Linear(256, 128),
                nn.ReLU(),
                nn.BatchNorm1d(num_features=128),
                nn.Dropout(0.4),
                nn.Linear(128, 9),
            )
        # self.linear_layers2 = nn.Sequential(
        #         nn.BatchNorm1d(256),
        #         nn.Linear(256, 128),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(num_features=128),
        #         nn.Dropout(0.4),
        #         nn.Linear(128, 32),
        #     )
    def forward(self, x):
        bs,_,_,_ = x.shape
        x1, x2, x3, x4, x5 = self.encoder(x)
        
        
        # x5 = self.t_hilo_block5(x5)
        # x4 = self.t_hilo_block4(x4)
        x3 = self.t_hilo_block3(x3)
        x2 = self.t_hilo_block2(x2)
        x3 = self.down_3(x3)
        x32 = self.effm32(x3, x2)
        
        
        x1 = self.conv_1(x1)
        x1 = self.t_s_block1(x1)
        
        x2 = self.down_2(x2)
        x21 = self.effm21(x32, x1)
        
        x_out = self._avg_pooling(x21)
        x_out = x_out.view(bs, -1)
        features1 = self.linear_layers(x_out)
        # features2 = self.linear_layers2(x_out)
        # b,_ = features2.shape
        # features3 = features2.reshape(b ,8,-1).contiguous()
        return torch.sigmoid(features1)
        
# model = model_Hilo()
        
# def count_parameters(model):
#     return sum(p.numel() for p in model.parameters() if p.requires_grad)   
# print(count_parameters(model))
