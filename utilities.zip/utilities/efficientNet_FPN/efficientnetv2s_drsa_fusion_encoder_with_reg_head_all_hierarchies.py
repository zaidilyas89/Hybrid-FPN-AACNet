import torch
import torch.nn as nn
# from .efficient_encoder import *
from einops import rearrange
import numbers
import math
import timm
from torch.nn import functional as F
##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma+1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma+1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        # h, w = x.shape[-2:]
        return self.body(x)

class LayerNorm_Channel(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm_Channel, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, hw, c = x.shape
        x = rearrange(x, 'b c (h w) -> b c h w', h=int(math.sqrt(c)), w = int(math.sqrt(c)))
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        x = rearrange(x, 'b c h w -> b c (h w)', h=int(math.sqrt(c)), w= int(math.sqrt(c)))
        return x

class Channel_FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(Channel_FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x

##########################################################################
class Channel_Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Channel_Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv = nn.Conv2d(dim, dim*3, kernel_size=1, bias=bias)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        


    def forward(self, x):
        b,c,h,w = x.shape

        qkv = self.qkv(x)
        q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)

        out = self.project_out(out)
        return out

class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q = nn.Linear(dim,dim, bias=False)
        self.k = nn.Linear(dim,dim, bias=False)
        self.v = nn.Linear(dim,dim, bias=False)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        # self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        # x = rearrange(x, 'b c h w -> b c (h w)')
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b feature seq -> b seq feature')
        k = rearrange(k, 'b feature seq -> b seq feature')
        v = rearrange(v, 'b feature seq -> b seq feature')

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
       
        out = rearrange(out, 'b seq feature -> b feature seq ')
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out

## Multi-DConv Head Transposed Self-Attention (MDTA)
class DRSA(nn.Module):
    def __init__(self, dim, num_heads, bias, channels, head_size):
        super(DRSA, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.head_size = head_size
        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q_Hi = nn.Linear(head_size,head_size, bias=False)
        self.k_Hi = nn.Linear(head_size,head_size, bias=False)
        self.v_Hi = nn.Linear(head_size,head_size, bias=False)
        self.q_Lo = nn.Linear(head_size,head_size, bias=False)
        self.k_Lo = nn.Linear(head_size,head_size, bias=False)
        self.v_Lo = nn.Linear(head_size,head_size, bias=False)
        
        self.downsample = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.convTranspose = nn.ConvTranspose2d(channels, channels, 2, 2)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        self.project_out = nn.Conv2d(channels, channels, kernel_size=1, bias=bias)
        # self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        b,c,h,w = x.shape
        x_Hi = x
        x_Lo = self.downsample(x)
        
        b_l, c_l, h_l, w_l = x_Lo.shape
        
        x_Hi = rearrange(x_Hi, 'b c h w -> b c (h w)')
        x_Hi = rearrange(x_Hi, 'b c (hw head) -> b hw c  head', head = self.head_size)
        q_Hi = self.q_Hi(x_Hi)
        k_Hi = self.k_Hi(x_Hi)
        v_Hi = self.v_Hi(x_Hi)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q_Hi = rearrange(q_Hi, 'b head c  hw -> b head hw c')
        k_Hi = rearrange(k_Hi, 'b head c  hw -> b head hw c')
        v_Hi = rearrange(v_Hi, 'b head c  hw -> b head hw c')

        q_Hi = torch.nn.functional.normalize(q_Hi, dim=-1)
        k_Hi = torch.nn.functional.normalize(k_Hi, dim=-1)

        attn_Hi = (q_Hi @ k_Hi.transpose(-2, -1)) * self.temperature
        attn_Hi = attn_Hi.softmax(dim=-1)

        out_Hi = (attn_Hi @ v_Hi)
        
        out_Hi = rearrange(out_Hi, 'b head hw c -> b head c hw')
        out_Hi = rearrange(out_Hi, 'b hw c head -> b c (hw head) ', head = self.head_size)
        out_Hi = rearrange(out_Hi, 'b c (h w) -> b c h w ', h = h, w = w)
        
                
        
        x_Lo = rearrange(x_Lo, 'b c h w -> b c (h w)')
        x_Lo = rearrange(x_Lo, 'b c (hw head) -> b hw c  head ', head = self.head_size)
        q_Lo = self.q_Lo(x_Lo)
        k_Lo = self.k_Lo(x_Lo)
        v_Lo = self.v_Lo(x_Lo)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q_Lo = rearrange(q_Lo, 'b head c  hw -> b head hw c')
        k_Lo = rearrange(k_Lo, 'b head c  hw -> b head hw c')
        v_Lo = rearrange(v_Lo, 'b head c  hw -> b head hw c')

        q_Lo = torch.nn.functional.normalize(q_Lo, dim=-1)
        k_Lo = torch.nn.functional.normalize(k_Lo, dim=-1)

        attn_Lo = (q_Lo @ k_Lo.transpose(-2, -1)) * self.temperature
        attn_Lo = attn_Lo.softmax(dim=-1)

        out_Lo = (attn_Lo @ v_Lo)
        
        out_Lo = rearrange(out_Lo, 'b head hw c -> b head c hw')
        out_Lo = rearrange(out_Lo, 'b hw c head -> b c (hw head) ', head = self.head_size)
        out_Lo = rearrange(out_Lo, 'b c (h w) -> b c h w ', h = h_l, w = w_l)
        
        out_Lo = self.convTranspose(out_Lo)
        
        out = out_Hi + out_Lo
        
        # out = rearrange(out, 'b c (h w) -> b c h w', h = h, w = w)
        
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out    

class Channel_Transformer(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias, LayerNorm_type):
        super(Channel_Transformer, self).__init__()

        self.norm1 = LayerNorm_Channel(dim, LayerNorm_type)
        self.attn = Channel_Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm_Channel(dim, LayerNorm_type)
        self.ffn = Channel_FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ffn(self.norm2(x))

        return x
    
class TransformerBlock(nn.Module):
    def __init__(self, dim=None, head_size=10, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(TransformerBlock, self).__init__()
        self.dim = dim
        self.head_size = head_size
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        # x = rearrange(x, 'b c (h w)-> b c h w ', h = h, w = w)
        x = x + self.attn(x)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x

class DRSAT(nn.Module):
    def __init__(self, dim=None, head_size=20, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(DRSAT, self).__init__()
        self.dim = dim
        self.head_size = head_size
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = DRSA(dim, num_heads, bias, channels, self.head_size)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        x = rearrange(x, 'b c (h w)-> b c h w ', h = h, w = w)
        x = x + self.attn(x)
        x = rearrange(x, 'b c h w-> b c (h w) ', h = h, w = w)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x

class EFFM(nn.Module):
    def __init__(self, x1_channels = None, x2_channels = None):
        super(EFFM, self).__init__()
        self.conv1 = nn.Conv2d(x1_channels+x2_channels, x2_channels, 1)
        self.channel_transformer = Channel_Transformer(dim=x2_channels, num_heads = 2, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.down =  nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
    def forward(self, x1 , x2):
        x = torch.cat([self.down(x1), x2], 1)
        x = self.conv1(x)
        x = self.channel_transformer(x)
        # x = self.down(x)
        return x

class model_DRSA(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = timm.create_model(
                                'tf_efficientnetv2_s',
                                pretrained=True,
                                features_only=True,
                                )
        
        # self.conv_1 = nn.Conv2d(in_channels=1536, out_channels=256, kernel_size=1, bias=False)
        # self.conv_1_1 = nn.Conv2d(in_channels=512, out_channels=512, kernel_size=1, bias=False)
        # self.conv_2 = nn.Conv2d(in_channels=192, out_channels=256, kernel_size=1, bias=False)
        # self.conv_3 = nn.Conv2d(in_channels=48, out_channels=96, kernel_size=1, bias=False)
        # self.conv_4 = nn.Conv2d(in_channels=64, out_channels=48, kernel_size=1, bias=False)
        # self.conv_5 = nn.Conv2d(in_channels=24, out_channels=32, kernel_size=1, bias=False)
        
        # self.conv_4 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=1, bias=False)
        
        self.t_s_block1 = TransformerBlock(dim=10*10, head_size=10, channels=256, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.t_s_block2 = TransformerBlock(dim=10*10, head_size=10, channels=512, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        self.t_DRSA_block2 = DRSAT(dim=20*20, channels=160, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.t_DRSA_block3 = DRSAT(dim=40*40, channels=64, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.t_DRSA_block4 = DRSAT(dim=80*80, channels=48, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.t_DRSA_block5 = DRSAT(dim=160*160, channels=24, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        # self.down_5 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_4 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_3 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_2 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        # self.down_1 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.effm54 = EFFM(x1_channels = 24, x2_channels = 48)
        self.effm43 = EFFM(x1_channels = 48, x2_channels = 64)        
        self.effm32 = EFFM(x1_channels = 64, x2_channels = 160)
        self.effm21 = EFFM(x1_channels = 160, x2_channels = 256)
        
        self._avg_pooling = nn.AdaptiveAvgPool2d(1)
        # self.linear_layers = nn.Sequential(
        #         nn.BatchNorm1d(num_features=512),    
        #         nn.Linear(512, 512),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(512),
        #         nn.Linear(512, 128),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(num_features=128),
        #         nn.Dropout(0.4),
        #         nn.Linear(128, 1),
        #     )
        # self.linear_layers2 = nn.Sequential(
        #         nn.BatchNorm1d(num_features=512),    
        #         nn.Linear(512, 512),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(512),
        #         nn.Linear(512, 128),
        #         nn.ReLU(),
        #         nn.BatchNorm1d(num_features=128),
        #         nn.Dropout(0.4),
        #         nn.Linear(128, 32),
        #     )
        self.linear_layers = nn.Sequential(
                nn.BatchNorm1d(256),
                nn.Linear(256, 128),
                nn.ReLU(),
                nn.BatchNorm1d(num_features=128),
                nn.Dropout(0.4),
                nn.Linear(128, 1),
            )
        self.linear_layers2 = nn.Sequential(
                nn.BatchNorm1d(256),
                nn.Linear(256, 128),
                nn.ReLU(),
                nn.BatchNorm1d(num_features=128),
                nn.Dropout(0.4),
                nn.Linear(128, 32),
            )
    def forward(self, x):
        bs,_,_,_ = x.shape
        x5, x4, x3, x2, x1 = self.encoder(x)
        
        # Shapes for (320, 320) input to EfficientNetv2s
        # x1 = (16, 256, 10, 10)
        # x2 = (16, 160, 20, 20)
        # x3 = (16, 64, 40, 40)
        # x4 = (16, 48, 80, 80)
        # x5 = (16, 24, 160, 160)
        
        x5 = self.t_DRSA_block5(x5)
        x4 = self.t_DRSA_block4(x4)
        x3 = self.t_DRSA_block3(x3)
        x2 = self.t_DRSA_block2(x2)
        x1 = self.t_s_block1(x1)
        # x3 = self.down_3(x3)
        
        x54 = self.effm54(x5, x4)
        x43 = self.effm43(x54, x3)
        x32 = self.effm32(x43, x2)
        x21 = self.effm21(x32, x1)        
        
        # x1 = self.conv_1(x1)

        
        # x2 = self.down_2(x2)

        
        x_out = self._avg_pooling(x21)
        x_out = x_out.view(bs, -1)
        features1 = self.linear_layers(x_out)
        features2 = self.linear_layers2(x_out)
        b,_ = features2.shape
        features3 = features2.reshape(b ,8,-1).contiguous()
        return torch.sigmoid(features1), features3
        
# model = model_DRSA()

# model = timm.create_model(
#                         'tf_efficientnetv2_m',
#                         pretrained=True,
#                         features_only=False,
#                         )        







# import torch
# import torch.utils.benchmark as benchmark

# # Define your model
# def count_parameters(model):
#     return sum(p.numel() for p in model.parameters() if p.requires_grad)   
# print(count_parameters(model))

# # Instantiate your model
# # model = MyModel()
# model.eval()  # Set the model to evaluation mode

# # Generate some random input data
# input_data = torch.randn(1, 3,320,320)

# # Run inference and measure the time
# timer = benchmark.Timer(
#     stmt="model(input_data)",
#     globals={"model": model, "input_data": input_data}
# )

# # Print the inference time
# print("Inference time:", timer.timeit(10))  # Adjust the number of iterations as needed


# model = model_DRSA()
        
# def count_parameters(model):
#     return sum(p.numel() for p in model.parameters() if p.requires_grad)   
# print(count_parameters(model))

# import torch
# import torch.utils.benchmark as benchmark

# # Define your model
# def count_parameters(model):
#     return sum(p.numel() for p in model.parameters() if p.requires_grad)   
# print(count_parameters(model))

# # Instantiate your model
# # model = MyModel()
# model.eval()  # Set the model to evaluation mode

# # Generate some random input data
# input_data = torch.randn(1, 3,320,320)

# # Run inference and measure the time
# timer = benchmark.Timer(
#     stmt="model(input_data)",
#     globals={"model": model, "input_data": input_data}
# )

# # Print the inference time
# print("Inference time:", timer.timeit(10))  # Adjust the number of iterations as needed

# from fvcore.nn import FlopCountAnalysis, parameter_count
# input_size = (1, 3, 320, 320)  # Example input size for CIFAR-10 dataset (with batch size 1)

# # Generate a random input tensor
# input_tensor = torch.randn(input_size)

# # Calculate FLOPs
# flops = FlopCountAnalysis(model, input_tensor)
# # flops = FlopCountAnalysis(model, input_tensor)
# print(f"FLOPs: {flops.total()}")
# # print(f"Parameters: {params}")
# from .kair_utils import get_model_activation, get_model_flops

# with torch.no_grad():
#     input_dim = (3, 320, 320)  # set the input dimension
#     # activations, num_conv2d = get_model_activation(model, input_dim)
#     # print('{:>16s} : {:<.4f} [M]'.format('#Activations', activations/10**6))
#     # print('{:>16s} : {:<d}'.format('#Conv2d', num_conv2d))
#     flops = get_model_flops(model, input_dim, False)
#     print('{:>16s} : {:<.4f} [G]'.format('FLOPs', flops/10**9))
#     # num_parameters = sum(map(lambda x: x.numel(), model.parameters()))
#     # print('{:>16s} : {:<.4f} [M]'.format('#Params', num_parameters/10**6))