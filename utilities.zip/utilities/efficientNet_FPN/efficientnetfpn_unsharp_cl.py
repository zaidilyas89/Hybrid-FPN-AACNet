import torch
import torch.nn as nn
from .efficient_encoder import *
from einops import rearrange
import numbers
import math
from torch.nn import functional as F
##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma+1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma+1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        # h, w = x.shape[-2:]
        return self.body(x)



##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, hw, c = x.shape
        x = rearrange(x, 'b c (h w) -> b c h w', h=int(math.sqrt(c)), w = int(math.sqrt(c)))
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        x = rearrange(x, 'b c h w -> b c (h w)', h=int(math.sqrt(c)), w= int(math.sqrt(c)))
        return x



##########################################################################
## Multi-DConv Head Transposed Self-Attention (MDTA)
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q = nn.Linear(dim,dim, bias=False)
        self.k = nn.Linear(dim,dim, bias=False)
        self.v = nn.Linear(dim,dim, bias=False)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        # self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        # x = rearrange(x, 'b c h w -> b c (h w)')
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b feature seq -> b seq feature')
        k = rearrange(k, 'b feature seq -> b seq feature')
        v = rearrange(v, 'b feature seq -> b seq feature')

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
       
        out = rearrange(out, 'b seq feature -> b feature seq ')
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out
 
## 
class Attention_Filters(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention_Filters, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q = nn.Linear(dim,dim, bias=False)
        self.k = nn.Linear(dim,dim, bias=False)
        self.v = nn.Linear(dim,dim, bias=False)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        # self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        # x = rearrange(x, 'b c h w -> b c (h w)')
        x_in = x
        b,c,h,w,f = x.shape
        x = rearrange(x, 'b c h w f -> b (c h w) f', h=h, w=w, c = c, f=f)
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)
        # q,k,v = qkv.chunk(3, dim=1)   
        q = rearrange(q, 'b (c h w) f -> b c f (h w)', h=h, w=w, c = c, f=f)
        k = rearrange(k, 'b (c h w) f -> b c f (h w)', h=h, w=w, c = c, f=f)
        v = rearrange(v, 'b (c h w) f -> b c f (h w)', h=h, w=w, c = c, f=f)
        


        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
        out = rearrange(out, 'b c f (h w) -> b (c h w) f',h=h, w=w, c = c, f=f)
        out = self.project_out(out)
        out = rearrange(out, 'b (c h w) f -> b c h w f', h=h, w=w, c = c, f=f)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out   
 
    
class TransformerBlock(nn.Module):
    def __init__(self, dim=None, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(TransformerBlock, self).__init__()
        self.dim = dim
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        x = x + self.attn(x)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x

class CustomKernel(nn.Module):
    def __init__(self, kernel_values):
        super(CustomKernel, self).__init__()

        # Initialize the kernel with predefined values
        self.kernel = nn.Parameter(kernel_values, requires_grad=False)

    def forward(self, x):
        # Assuming x is your input tensor
        # Apply the convolution operation using your custom kernel
        result = torch.nn.functional.conv2d(x, self.kernel,groups=x.size(1),padding='same')
        
        return result

class EF_Block(nn.Module):
    def __init__(self, dim=None, channels=None, num_heads=None, f_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(EF_Block, self).__init__()
        self.dim = dim
        self.channels = channels
        self.f_heads = f_heads
        self.conv2d_usharp_3_kernel = torch.tensor([[0, 1, 0],
                                                     [1, -4, 1],
                                                     [0, 1, 0]], dtype=torch.float32)
        self.conv2d_usharp_3_kernel = self.conv2d_usharp_3_kernel.unsqueeze(0).unsqueeze(0).expand(self.dim, 1, -1, -1)
        
        self.conv2d_usharp_3 = CustomKernel(self.conv2d_usharp_3_kernel)
        
        self.conv2d_usharp_5_kernel = torch.tensor([[0, 1, 0, 1, 1],
                                                    [0, 1, 0, 1, 1],
                                                     [1, -4, 1, 1, 1],
                                                     [0, 1, 0, 1, 1],
                                                     [0, 1, 0, 1, 1]], dtype=torch.float32)
        self.conv2d_usharp_5_kernel = self.conv2d_usharp_5_kernel.unsqueeze(0).unsqueeze(0).expand(self.dim, 1, -1, -1)
        
        self.conv2d_usharp_5 = CustomKernel(self.conv2d_usharp_5_kernel)
        
        self.conv2d_usharp_7_kernel = torch.tensor([[0, 1, 0, 1, 1, 1, 1],
                                                    [0, 1, 0, 1, 1, 1, 1],
                                                    [0, 1, 0, 1, 1, 1, 1],
                                                    [0, 1, 0, 1, 1, 1, 1],
                                                     [1, -4, 1, 1, 1, 1, 1],
                                                     [0, 1, 0, 1, 1, 1, 1],
                                                     [0, 1, 0, 1, 1, 1, 1]], dtype=torch.float32)
        self.conv2d_usharp_7_kernel = self.conv2d_usharp_7_kernel.unsqueeze(0).unsqueeze(0).expand(self.dim, 1, -1, -1)
        
        self.conv2d_usharp_7 = CustomKernel(self.conv2d_usharp_5_kernel)
        
        # self.conv2d_usharp_9_kernel = torch.tensor([[0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                             [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                             [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                             [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                             [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                             [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                              [1, -4, 1, 1, 1, 1, 1, 1, 1],
        #                                              [0, 1, 0, 1, 1, 1, 1, 1, 1],
        #                                              [0, 1, 0, 1, 1, 1, 1, 1, 1]], dtype=torch.float32)
        
        # self.conv2d_usharp_9 = CustomKernel(self.conv2d_usharp_9_kernel)
        
        self.project_out = nn.Conv2d(in_channels=channels*self.f_heads, out_channels=channels, kernel_size=1, bias=False)
        
        self.attn = Attention_Filters(self.f_heads, dim, bias)
        self.norm1 = LayerNorm(self.f_heads, LayerNorm_type)
        self.norm2 = LayerNorm(self.f_heads, LayerNorm_type)
        self.ffn = FeedForward(channels*self.f_heads, ffn_expansion_factor, bias)
        
    def forward(self, x):
        x_in = x
        
        x3 = self.conv2d_usharp_3(x)
        x5 = self.conv2d_usharp_5(x)
        x7 = self.conv2d_usharp_7(x)
        # x9 = self.conv2d_usharp_9(x)
        
        b,c,h,w = x.shape
        x = torch.cat((x3.unsqueeze(-1), x5.unsqueeze(-1), x7.unsqueeze(-1)), dim=-1)
        # x3 = rearrange(x3, 'b c h w -> b c (h w)', h = h, w = w)
        # x5 = rearrange(x5, 'b c h w -> b c (h w)', h = h, w = w)
        # x7 = rearrange(x7, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        x = self.attn(x) + x
        x = self.norm2(x)
        b_,c_,h_,w_,f_ = x.shape
        x = rearrange(x, 'b c h w f -> b (c f) (h w)', h = h_, w = w_, c = c_, f = f_, b = b_)
        x = self.ffn(x) + x
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        x = self.project_out(x)
        x = x + x_in
        return x


# filter_kernel = filter_kernel.unsqueeze(0).unsqueeze(0).expand(-1, image_tensor.shape[1], -1, -1)
class model_FPN(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = get_efficientEncoder_b3(out_channels=2, concat_input=True, pretrained=True)
        self.conv_1 = nn.Conv2d(in_channels=1536, out_channels=256, kernel_size=1, bias=False)
        self.conv_3 = nn.Conv2d(in_channels=48, out_channels=96, kernel_size=1, bias=False)
        self.conv_2 = nn.Conv2d(in_channels=192, out_channels=256, kernel_size=1, bias=False)
        # self.conv_4 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=1, bias=False)
        
        self.ef_block3 = EF_Block(dim=48, channels=48, num_heads=4, f_heads=3, ffn_expansion_factor=1, bias=False, LayerNorm_type='WithBias')
        self.ef_block2 = EF_Block(dim=96, channels=96, num_heads=4, f_heads=3, ffn_expansion_factor=1, bias=False, LayerNorm_type='WithBias')
        self.ef_block1 = EF_Block(dim=1536, channels=1536, num_heads=4, f_heads=3, ffn_expansion_factor=1, bias=False, LayerNorm_type='WithBias')
        
        self.transformer_block_last = TransformerBlock(dim=10*10, channels=1792, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.transformer_block_1 = TransformerBlock(dim=10*10, channels=256, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.transformer_block_2 = TransformerBlock(dim=20*20, channels=96, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        # self.transformer_block_3 = TransformerBlock(dim=40*40, channels=48, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        self.downsample_32 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.downsample_21 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        
        self._avg_pooling = nn.AdaptiveAvgPool2d(1)
        # self._fc = nn.Sequential(
        #             nn.BatchNorm1d(num_features=512),    
        #             nn.Linear(512, 128),
        #             nn.ReLU(),
        #             nn.BatchNorm1d(num_features=128),
        #             nn.Dropout(0.4),
        #             nn.Linear(128, 1),
        #         )
        self._fc = nn.Sequential(
                nn.BatchNorm1d(1792),
                nn.Linear(1792, 128),
                nn.ReLU(),
                           )
        self.fc_ordering = nn.Sequential(
                nn.BatchNorm1d(num_features=128),    
                nn.Linear(128, 1),
                nn.Sigmoid())
    def forward(self, x):
        bs,_,_,_ = x.shape
        x1, x2, x3, _, _ = self.encoder(x)
        x1 = self.ef_block1(x1) # 1536 channel
        x2 = self.ef_block2(x2) # 96 channel
        x3 = self.ef_block3(x3) # 48 channel
        x32 = self.conv_3(x3)
        x32 = self.downsample_32(x32)
        x2_32 = torch.cat([x2, x32], 1)
        x2_32 = self.conv_2(x2_32)
        x2_32 = self.downsample_21(x2_32)
        x21_2_32 = torch.cat([x1, x2_32], 1)
        x21_2_32 = self.transformer_block_last(x21_2_32) + x21_2_32
        # x11 = self.conv_4(x11)
        x_out = self._avg_pooling(x21_2_32)
        x_out = x_out.view(bs, -1)
        # x_out = torch.sigmoid(self._fc(x_out))
        
        output = self._fc(x_out)
        order = self.fc_ordering(output)
        
        return output, order
        
        
