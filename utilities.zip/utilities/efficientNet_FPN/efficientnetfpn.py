import torch
import torch.nn as nn
from .efficient_encoder import *
from einops import rearrange
import numbers
import math
from torch.nn import functional as F
##########################################################################
## Layer Norm

def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')

def to_4d(x,h,w):
    return rearrange(x, 'b (h w) c -> b c h w',h=h,w=w)

class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma+1e-5) * self.weight

class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma+1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type =='BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        # h, w = x.shape[-2:]
        return self.body(x)



##########################################################################
## Gated-Dconv Feed-Forward Network (GDFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim*ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features*2, kernel_size=1, bias=bias)

        self.dwconv = nn.Conv2d(hidden_features*2, hidden_features*2, kernel_size=3, stride=1, padding=1, groups=hidden_features*2, bias=bias)

        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, hw, c = x.shape
        x = rearrange(x, 'b c (h w) -> b c h w', h=int(math.sqrt(c)), w = int(math.sqrt(c)))
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        x = rearrange(x, 'b c h w -> b c (h w)', h=int(math.sqrt(c)), w= int(math.sqrt(c)))
        return x



##########################################################################
## Multi-DConv Head Transposed Self-Attention (MDTA)
class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # self.qkv = nn.Conv2d(81, 81*3, kernel_size=1, bias=bias)
        self.q = nn.Linear(dim,dim, bias=False)
        self.k = nn.Linear(dim,dim, bias=False)
        self.v = nn.Linear(dim,dim, bias=False)
        # self.qkv_dwconv = nn.Conv2d(dim*3, dim*3, kernel_size=3, stride=1, padding=1, groups=dim*3, bias=bias)
        # self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.project_out = nn.Linear(dim,dim, bias=False)
        


    def forward(self, x):
        # b,c,h,w = x.shape
        # qkv = self.qkv_dwconv(self.qkv(x))
        # x1=x
        # x = rearrange(x, 'b c h w -> b c (h w)')
        q = self.q(x)
        k = self.k(x)
        v = self.v(x)
        # q,k,v = qkv.chunk(3, dim=1)   
        
        q = rearrange(q, 'b feature seq -> b seq feature')
        k = rearrange(k, 'b feature seq -> b seq feature')
        v = rearrange(v, 'b feature seq -> b seq feature')

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)

        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)

        out = (attn @ v)
        
       
        out = rearrange(out, 'b seq feature -> b feature seq ')
        out = self.project_out(out)
        # out = rearrange(out, 'b c (h w) -> b c h w', h=9,w=9)
        return out
    
    
class TransformerBlock(nn.Module):
    def __init__(self, dim=None, channels=None, num_heads=None, ffn_expansion_factor=None, bias=False, LayerNorm_type='WithBias'):
        super(TransformerBlock, self).__init__()
        self.dim = dim
        self.channels = channels
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(channels, ffn_expansion_factor, bias)
        
    def forward(self, x):
        b,c,h,w = x.shape
        x = rearrange(x, 'b c h w -> b c (h w)', h = h, w = w)
        x = self.norm1(x)
        # x = rearrange(x, 'b c (h w) -> b c h w', h = 9, w = 9)
        x = x + self.attn(x)
        x = x + self.ffn(self.norm2(x))
        x = rearrange(x, 'b c (h w) -> b c h w', h = h, w = w)
        return x



class model_FPN(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = get_efficientEncoder_b2(out_channels=2, concat_input=True, pretrained=True)
        self.conv_1 = nn.Conv2d(in_channels=1536, out_channels=256, kernel_size=1, bias=False)
        self.conv_3 = nn.Conv2d(in_channels=48, out_channels=96, kernel_size=1, bias=False)
        self.conv_2 = nn.Conv2d(in_channels=192, out_channels=256, kernel_size=1, bias=False)
        # self.conv_4 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=1, bias=False)
        
        self.transformer_block_last = TransformerBlock(dim=10*10, channels=512, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.transformer_block_1 = TransformerBlock(dim=10*10, channels=256, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.transformer_block_2 = TransformerBlock(dim=20*20, channels=96, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        self.transformer_block_3 = TransformerBlock(dim=40*40, channels=48, num_heads=1, ffn_expansion_factor=2, bias=False, LayerNorm_type='WithBias')
        
        self.downsample_32 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        self.downsample_21 = nn.MaxPool2d(kernel_size=2,stride=2,padding=0)
        
        self._avg_pooling = nn.AdaptiveAvgPool2d(1)
        self._fc = nn.Sequential(
                    nn.BatchNorm1d(num_features=512),    
                    nn.Linear(512, 128),
                    nn.ReLU(),
                    nn.BatchNorm1d(num_features=128),
                    nn.Dropout(0.4),
                    nn.Linear(128, 1),
                )
        
    def forward(self, x):
        bs,_,_,_ = x.shape
        x1, x2, x3, _, _ = self.encoder(x)
        x1 = self.conv_1(x1)
        x1 = self.transformer_block_1(x1)
        x2 = self.transformer_block_2(x2)
        x3 = self.transformer_block_3(x3)
        x3 = self.conv_3(x3)
        x3 = self.downsample_32(x3)
        x32 = torch.cat([x3, x2], 1)
        x32 = self.conv_2(x32)
        x21 = self.downsample_21(x32)
        x11 = torch.cat([x21, x1], 1) 
        x11 = self.transformer_block_last(x11)
        # x11 = self.conv_4(x11)
        x_out = self._avg_pooling(x11)
        x_out = x_out.view(bs, -1)
        x_out = torch.sigmoid(self._fc(x_out))
        
        
        
        return x_out
        
        

