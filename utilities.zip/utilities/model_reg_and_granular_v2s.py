
import numpy as np
import os
import glob
import torch
import torchvision
# import torchvision.models as models

from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
from torchvision import transforms, utils
from skimage.transform import resize
import collections
import time
from tqdm import tqdm
import copy
from PIL import Image
# from kair_utils import get_model_activation, get_model_flops
from sklearn import  metrics
import pandas as pd
from torch.utils.data import Sampler
from torch.utils.data import BatchSampler
from torch.utils.data import DataLoader
from sklearn.model_selection import StratifiedKFold
# import pretrainedmodels
# import visdom
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from torchsampler import ImbalancedDatasetSampler
seed = 3
import torchvision.transforms as transforms
torch.manual_seed(seed)
from sklearn.metrics import confusion_matrix
import scipy.stats         
from torchvision.models.efficientnet import efficientnet_v2_s
import matplotlib.pyplot as plt
import json
from sklearn.metrics import cohen_kappa_score


class model_reg_and_gran(nn.Module):
    def __init__(self):
        super(model_reg_and_gran, self).__init__()
        
        self.model = efficientnet_v2_s()
        # self.model._fc
        # self.net.maxpool = nn.Identity()
        
        self.num_ftrs = self.model.classifier[1].in_features
        
        self.linear_layers = nn.Sequential(
                nn.BatchNorm1d(num_features=self.num_ftrs),    
                nn.Linear(self.num_ftrs, 512),
                nn.ReLU(),
                nn.BatchNorm1d(512),
                nn.Linear(512, 128),
                nn.ReLU(),
                nn.BatchNorm1d(num_features=128),
                nn.Dropout(0.4),
                nn.Linear(128, 1),
            ).cuda()
        self.linear_layers2 = nn.Sequential(
                nn.BatchNorm1d(num_features=self.num_ftrs),    
                nn.Linear(self.num_ftrs, 512),
                nn.ReLU(),
                nn.BatchNorm1d(512),
                nn.Linear(512, 128),
                nn.ReLU(),
                nn.BatchNorm1d(num_features=128),
                nn.Dropout(0.4),
                nn.Linear(128, 32),
            ).cuda()
        self.model=self.model.cuda()
        
      
        # self.model.fc1=self.linear_layers.cuda()
        # self.model.fc2=self.linear_layers2.cuda()
                
        # for param in self.model.parameters():
        #     param.require_grad = True

        # for param in self.model._fc.parameters():
        #     param.require_grad = True
            
    def forward(self, x): 
        x = self.model(x)
        features1,features2 = self.linear_layers2(x), self.linear_layers1(x)
        b,_ = features2.shape
        features3 = features2.reshape(b ,8,-1).contiguous()
        return torch.sigmoid(features1),features3        





# class Last_Layer(nn.Module):
#     def __init__(self, model, num_ftrs):
#         super(Last_Layer, self).__init__()
#         self.linear_layers = nn.Sequential(
#                 nn.BatchNorm1d(num_features=num_ftrs),    
#                 nn.Linear(num_ftrs, 512),
#                 nn.ReLU(),
#                 nn.BatchNorm1d(512),
#                 nn.Linear(512, 128),
#                 nn.ReLU(),
#                 nn.BatchNorm1d(num_features=128),
#                 nn.Dropout(0.4),
#                 nn.Linear(128, 1),
#             )
#         self.model=model
        
      
#         self.model._fc=self.linear_layers
        
                
#         for param in self.model.parameters():
#             param.require_grad = True

#         for param in self.model._fc.parameters():
#             param.require_grad = True
            
#     def forward(self, x): 
#         return torch.sigmoid(self.model(x))
    
    
def weights_init(m):
        if isinstance(m, torch.nn.Linear):
            torch.manual_seed(3)
            torch.nn.init.xavier_normal_(m.weight.data, gain=nn.init.calculate_gain('relu'))
            #torch.nn.init.kaiming_normal_(m.weight.data, mode='fan_in', nonlinearity='relu')
            #torch.nn.init.zeros_(m.bias.data)
            
         
# network = EfficientNet_local.from_pretrained('efficientnet-b3')
# num_ftrs = network._fc.in_features


# model = Last_Layer(network,num_ftrs)


###############################################################################
# class Net_CL(nn.Module):
#     def __init__(self):
#         super().__init__()
#         self.net = EfficientNet_local.from_pretrained('efficientnet-b3')
#         # self.net.maxpool = nn.Identity()
#         self.num_ftrs = self.net._fc.in_features
#         # self.net._fc = nn.Sequential(nn.Linear(self.num_ftrs, projection_units),
#         #                        nn.ReLU())
#         self.net._fc = nn.Sequential(
#                 nn.BatchNorm1d(num_features=self.num_ftrs),    
#                 nn.Linear(self.num_ftrs, 512),
#                 nn.ReLU(),
#                 nn.BatchNorm1d(512),
#                 nn.Linear(512, 128),
#                 nn.ReLU(),
#                 nn.BatchNorm1d(num_features=128),
#                 nn.Dropout(0.4),
#                 nn.Linear(128, 1),
#             )
#     def forward(self,x):
#         output = torch.sigmoid(self.net(x))
#         return output

# class Net_CL(nn.Module):
#     def __init__(self):
#         super().__init__()
#         self.net = EfficientNet_local.from_pretrained('efficientnet-b3')
#         # self.net.maxpool = nn.Identity()
#         self.num_ftrs = self.net._fc.in_features
#         # self.net._fc = nn.Sequential(nn.Linear(self.num_ftrs, projection_units),
#         #                        nn.ReLU())
#         self.net._fc = nn.Sequential(
#                     nn.BatchNorm1d(num_features=self.net._fc.in_features),    
#                     nn.Linear(self.net._fc.in_features, 512),
#                     nn.ReLU(),
#                     nn.BatchNorm1d(512),
#                     nn.Linear(512, 256),
#                     nn.ReLU(),
#                     nn.BatchNorm1d(num_features=256),
#                     nn.Linear(256, 128),
#                     nn.ReLU(),
#                     nn.BatchNorm1d(num_features=128),
#                     nn.Dropout(0.4),
#                     nn.Linear(128, 64),
#                     nn.ReLU(),
#                     nn.BatchNorm1d(num_features=64),
#                     nn.Linear(64, 1),
#                     nn.Sigmoid()
#                 ).cuda()
        
#     def forward(self,x):
#         output = self.net(x)
#         return output

# model = Net_CL()

# path = './caifos_efficient-netb3_mse_70.3125acc_1th-fold_lr-0.00050_sen-87.50_spec-89.375_corr-0.856_epoch-78.00_pv-0.00_rho-0.81_prho-0.00.pt'
# moda = EfficientNet_local.from_pretrained('efficientnet-b3')
# mod = torch.load(path)
# a = moda._blocks
# moda.load_state_dict(mod)
# a = moda.state_dict()

# moda._blocks[0]._modules['_bn1'].load_state_dict(mod['model._blocks.0._bn1.bias'])
# moda._blocks[0]._modules['_bn1'].weight
# a[24]._modules["_expand_conv"]

###############################################################################

# model =self.transformer_block
# with torch.no_grad():
#     input_dim = (3, 300, 300)  # set the input dimension
#     activations, num_conv2d = get_model_activation(model, input_dim)
#     print('{:>16s} : {:<.4f} [M]'.format('#Activations', activations/10**6))
#     print('{:>16s} : {:<d}'.format('#Conv2d', num_conv2d))
#     flops = get_model_flops(model, input_dim, False)
#     print('{:>16s} : {:<.4f} [G]'.format('FLOPs', flops/10**9))
#     num_parameters = sum(map(lambda x: x.numel(), model.parameters()))
#     print('{:>16s} : {:<.4f} [M]'.format('#Params', num_parameters/10**6))

