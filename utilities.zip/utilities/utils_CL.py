# -*- coding: utf-8 -*-
"""
Created on Wed May 17 14:29:59 2023

@author: zaidi
"""
import torch
import torchvision.transforms as transforms
import time
import copy
from .pytorchtools import EarlyStopping
from tqdm import tqdm
from sklearn.metrics import confusion_matrix
from sklearn.metrics import cohen_kappa_score
import scipy
import numpy as np
from PIL import Image
import logging
from collections import defaultdict
import pandas as pd


def get_data_dist(df):
    dist = df['image_id']
    a = df.labels.value_counts()
    b=pd.DataFrame(a)
    aa = 1 - a/a.sum()
    bb = pd.DataFrame(aa)
    cc = pd.concat([b,bb],1)
    # cc.to_csv('Manitoba_1916_dist.csv',)
    missing = []
    for i in range(0,25):
        if i not in cc.index:
            missing.append(i)
            

    return dist




# def mse_loss_weighted(input, target):
#     return torch.sum((input - target) ** 2)

# def mse_loss(input, target):
#     l = (input - target) ** 2
    
#     a = torch.from_numpy(np.array(list(set(np.uint8(target.cpu().detach()*24)[:,0])))).unsqueeze(1).to(input.device)
#     b = torch.from_numpy(np.uint8(target.cpu().detach()*24)[:,0]).unsqueeze(1).to(input.device)
#     mask = torch.eq(a,b.T)*1

#     aa = torch.matmul(mask.type(torch.float16),l.type(torch.float16))
#     counts = torch.count_nonzero(a,axis=1)
#     return l.sum()

def weighted_mse_loss(input, target, weight):
        return (weight * (input - target) ** 2).mean()

def define_transforms(opt):
    train_CL_transforms = transforms.Compose([transforms.ToPILImage(),
                                     transforms.RandomApply(torch.nn.ModuleList([transforms.RandomRotation(15,fill=0),
                                                            transforms.RandomAffine(degrees=0, shear=(0.05),fill=0,),
                                                            transforms.RandomAffine(degrees=0, translate=(0.05, 0.05),fill=0)]), p=0.5),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])

    val_transforms = transforms.Compose([transforms.ToPILImage(),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])
    
    train_transforms = transforms.Compose([
                                    transforms.ToPILImage(),
                            
                                    transforms.RandomApply(torch.nn.ModuleList([
                                        transforms.RandomAffine(degrees=10, translate=(
                                            0.05, 0.05), scale=(.95, 1.05), shear=(0.01, 0.03)),
                                        transforms.RandomAffine(
                                            degrees=5),
                                        transforms.RandomAffine(
                                            degrees=0, translate=(0.1, 0.1)),
                                        transforms.RandomAffine(
                                            degrees=0, scale=(.95, 1.05)),
                                        transforms.RandomAffine(
                                            degrees=0, shear=(0.005, 0.02)),
                                    ]), p=0.5),
                            
                                    transforms.Resize(
                                        opt['shape'][0], interpolation=Image.NEAREST),
                            
                                    transforms.ToTensor(),
                                    transforms.Normalize((0.5,0.5,0.5), (0.5,0.5,0.5))])
                            

    # train_transforms = transforms.Compose([
    #                                 transforms.ToPILImage(),
                            
    #                                 transforms.RandomApply(torch.nn.ModuleList([
    #                                     transforms.RandomAffine(degrees=10, translate=(
    #                                         0.1, 0.1), scale=(.9, 1.1), shear=(0.01, 0.03)),
    #                                     transforms.RandomAffine(
    #                                         degrees=5),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, translate=(0.1, 0.1)),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, scale=(.9, 1.1)),
    #                                     transforms.RandomAffine(
    #                                         degrees=0, shear=(0.005, 0.02)),
    #                                 ]), p=0.5),
                            
    #                                 transforms.Resize(
    #                                     opt['shape'][0], interpolation=Image.NEAREST),
                            
    #                                 transforms.ToTensor(),
    #                                 transforms.Normalize(
    #                                    opt['mean'], opt['std'])
                            
    #                             ])
    
    return train_transforms, val_transforms

def r2_score(target, prediction):
    """Calculates the r2 score of the model
    
    Args-
        target- Actual values of the target variable
        prediction- Predicted values, calculated using the model
        
    Returns- 
        r2- r-squared score of the model
    """
    r2 = 1- torch.sum((target-prediction)**2) / torch.sum((target-target.float().mean())**2)
    return r2

def train_model(model, criterion, optimizer, num_epochs, dataloaders, dataset_sizes, device, fold, logger):
    start = time.time()
    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0
    best_loss = np.inf
    history = defaultdict(list)
    # scaler = amp.GradScaler()

    for step, epoch in enumerate(range(1,num_epochs+1)):
        print('Epoch {}/{}'.format(epoch, num_epochs))
        print('-' * 10)

        # Each epoch has a training and validation phase
        for phase in ['train']:
            if(phase == 'train'):
                model.train() # Set model to training mode
            else:
                model.eval() # Set model to evaluation mode
            
            running_loss = 0.0
            running_loss_CL = 0.0
            running_loss_Reg = 0.0
            running_corrects = 0
            # Iterate over data
            for inputs,labels,fname in tqdm(dataloaders[phase]):
                inputs = inputs.to(device)
                labels = labels.to(device)

                

                
                # forward
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    
                    outputs, order = model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss_CL = criterion[0](outputs, labels * 24)
                    loss_Reg = criterion[1](order, labels.unsqueeze(-1))
                    # loss_Reg = mse_loss(order, labels.unsqueeze(-1))
                    loss = (loss_CL) + (loss_Reg)
                    # loss = loss / 4
                    
                    # backward only if in training phase
                    if phase == 'train':
                        loss.backward()

                    # optimize only if in training phase
                    if phase == 'train':
                        optimizer.step()
                        # scaler.update()
                        # scheduler.step()
                        
                        # zero the parameter gradients
                        optimizer.zero_grad()


                running_loss += loss.item()*inputs.size(0)
                running_loss_CL += loss_CL.item()*inputs.size(0)
                running_loss_Reg += loss_Reg.item()*inputs.size(0)
                # running_corrects += torch.sum(preds == labels.data)
            
            epoch_loss = running_loss/dataset_sizes[phase]   
            epoch_loss_CL = running_loss_CL/dataset_sizes[phase] 
            epoch_loss_Reg = running_loss_Reg/dataset_sizes[phase]
            # epoch_acc = running_corrects.double() / dataset_sizes[phase]
            history[phase + ' loss'].append(epoch_loss)

            print('{} Loss: {:.4f} Loss_CL: {:.4f} Loss_Reg: {:.4f}'.format(
                phase, epoch_loss, epoch_loss_CL, epoch_loss_Reg))
            logger.debug('{} Loss: {:.4f} Loss_CL: {:.4f} Loss_Reg: {:.4f}'.format(
                phase, epoch_loss, epoch_loss_CL, epoch_loss_Reg))
            
            # deep copy the model
            # if phase=='valid' and epoch_acc > best_acc:
            #     best_acc = epoch_acc
            #     best_model_wts = copy.deepcopy(model.state_dict())
            #     PATH = f"Fold{fold}_{best_acc}_epoch_{epoch}.bin"
            #     torch.save(model.state_dict(), PATH)
            if phase=='train' and epoch_loss_CL <= best_loss:
                best_loss = epoch_loss_CL
                best_model_wts = copy.deepcopy(model.state_dict())
                
                PATH = f"Fold{fold}_CL_DXA_{best_loss}_epoch_{epoch}.bin"
                torch.save(model.state_dict(), PATH)

        print()

    end = time.time()
    time_elapsed = end - start
    print('Training complete in {:.0f}h {:.0f}m {:.0f}s'.format(
        time_elapsed // 3600, (time_elapsed % 3600) // 60, (time_elapsed % 3600) % 60))
    print("Best Loss ",best_loss)
    logger.debug('Training complete in {:.0f}h {:.0f}m {:.0f}s'.format(
        time_elapsed // 3600, (time_elapsed % 3600) // 60, (time_elapsed % 3600) % 60))
    logger.debug("Best Loss ",best_loss)
    # load best model weights
    model.load_state_dict(best_model_wts)
    return model, history

